﻿using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IMasterDataService
    {
        List<VMasterDataRoutingModel> GetMasterdata(PMTsDbContext context, HttpContext sessionContext, string TxtSearch, string ddlSearch);
        VMasterDataViewModel GetMasterdataListView(PMTsDbContext context, SessionsModel sessions);
        VMasterDataViewModel GetMasterdataListViewSearch(PMTsDbContext context, SessionsModel sessions, string TxtSearch, string ddlSearch);
    }
}
