﻿using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IProductCustomerService
    {
        void GetCustomer(TransactionDataModel transactionDataModel);
        TransactionDataModel CustomerData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel transactionDataModel);
    }
}
