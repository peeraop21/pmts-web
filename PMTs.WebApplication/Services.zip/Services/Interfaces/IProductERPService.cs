﻿using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IProductERPService
    {
        TransactionDataModel ProductERPData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel model);
        TransactionDataModel PlantViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PlantData);
        bool ChkPlantMat(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PlantData, string btnSave);
        string GenPurch(PMTsDbContext context, string Plant);
        TransactionDataModel SavePlantViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PlantData, string btnSave);
        TransactionDataModel UpdatePlantViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PlantData, String UpdateBtn);
        TransactionDataModel DeletePlantViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel model, String btnDeleteERP);
        TransactionDataModel SaleViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData);
        bool ChkSaleMat(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData, string btnSave);
        TransactionDataModel SaveSaleViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData, string btnSave);
        TransactionDataModel UpdateSaleViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData, String UpdateBtn);
        TransactionDataModel DeleteSaleViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData, String UpdateBtn);
        TransactionDataModel PurchaseViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PurchaseData);
        TransactionDataModel SavePurchaseViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PurData);
    }
}

