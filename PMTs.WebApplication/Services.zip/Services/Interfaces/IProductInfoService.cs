﻿using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelPresale;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IProductInfoService
    {
        TransactionDataModel ProductInfoGetData(PMTsDbContext context, HttpContext sessionContext);
        TransactionDataModel ProductInfoData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel ProdInfo);
        void SaveMasterData(PMTsDbContext context, HttpContext sessionContext, PresaleContext presaleContext, TransactionDataModel model, string MatNo);
        string GenMatNo(PMTsDbContext context, string MatType, SessionsModel Sessions);
        bool DescriptionChack(PMTsDbContext context, string Description, SessionsModel Sessions);
        bool ProdCodeChack(PMTsDbContext context, string ProdCode, SessionsModel Sessions);
    }
}
