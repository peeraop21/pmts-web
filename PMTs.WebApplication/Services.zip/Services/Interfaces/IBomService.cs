﻿using PMTs.DataAccess;
using PMTs.DataAccess.ModelView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IBomService
    {
        BOMViewModel GetMatParent(PMTsDbContext context, string txtSearch, string ddlSearch);
        BOMViewModel GetMatChild(PMTsDbContext context, BOMViewModel model);
        BOMViewModel GetBomStruct(PMTsDbContext context, string materialNo);
    }
}
