﻿using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface ICategoryService
    {
        TransactionDataModel BindDataToModelCategoriesCreate(TransactionDataModel model, string ActionTran);

        TransactionDataModel BindDataToModelCategoriesBackward(TransactionDataModel model);

        TransactionDataModel SaveDataToModel_Categories(TransactionDataModel temp);

        TransactionDataModel GetCategoriesData();
    }
}
