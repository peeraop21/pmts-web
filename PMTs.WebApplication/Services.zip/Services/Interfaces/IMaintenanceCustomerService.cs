﻿using PMTs.DataAccess.ModelView.MaintenanceCustomer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IMaintenanceCustomerService
    {
        void GetCustomer(MaintenanceCustomerViewModel maintenanceCustomerViewModel);
        void SaveCustomer(MaintenanceCustomerViewModel maintenanceCustomerViewModel);
        void UpdateCustomer(CustomerViewModel customerViewModel);
        void SetCustomerStatus(CustomerViewModel customerViewModel);
    }
}
