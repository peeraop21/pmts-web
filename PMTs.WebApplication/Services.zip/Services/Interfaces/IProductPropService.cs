﻿using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IProductPropService
    {
        TransactionDataModel ProductPropData(TransactionDataModel model);

        TransactionDataModel ProductProp(TransactionDataModel Propdata);

        TransactionDataModel SavePropData(TransactionDataModel temp);

        TransactionDataModel UpdateChangeHisData(TransactionDataModel temp);
    }
}
