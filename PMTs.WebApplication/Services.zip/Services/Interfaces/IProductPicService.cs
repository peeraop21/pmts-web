﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IProductPicService
    {
        TransactionDataModel PicData(IHostingEnvironment environment);

        void SetPicData(string[,] Base64);

        TransactionDataModel UpdateData(TransactionDataModel model, string MaterialNo, TransactionDataModel Transaction, IHostingEnvironment environment, string Page);
    }
}
