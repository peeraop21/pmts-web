﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface INewProductService
    {
        MasterDataTransactionModel GetMasterDataTransaction(PMTsDbContext dbContext, string actionTran, string materialNo);
        MasterDataTransactionModel GetMasterDataTransactionPresale(PMTsDbContext dbContext, MasterDataTransactionModel oMasterData);
        TransactionDataModel BindDataToModelEditCopy(PMTsDbContext dbContext, HttpContext httpContext, IHostingEnvironment hostEnvironment, string actionTran, string MaterialNo, MasterDataTransactionModel masterDataTran);
        ProductERPPurchaseViewModel BindDataPurchase(PMTsDbContext dbContext, MasterDataTransactionModel obj);
        ProductERPPurchaseViewModel BindDataPurchaseByMatNo(PMTsDbContext dbContext, string materialNo);
        ProductPropViewModel BindProductProp(PMTsDbContext dbContext, MasterDataTransactionModel obj);
        ProductCustomer BindCustomerData(PMTsDbContext dbContext, MasterDataTransactionModel obj);
        RoutingViewModel BindRoutingData(PMTsDbContext dbContext, MasterDataTransactionModel obj, ProductSpecViewModel modelProductSpec);
        ViewCategories BindCategoriesData(PMTsDbContext dbContext, MasterDataTransactionModel obj);
        ViewCategories BindCategoriesPresaleData(PMTsDbContext dbContext, string MaterialNo);
        ProductSpecViewModel BindProductSpecData(PMTsDbContext dbContext, HttpContext httpContext, MasterDataTransactionModel obj, IHostingEnvironment hostEnvironment);
        ProductInfoView BindProductInfoData(PMTsDbContext dbContext, MasterDataTransactionModel obj);
        ProductPictureView BindProductPictureData(PMTsDbContext dbContext, MasterDataTransactionModel obj, IHostingEnvironment hostEnvironment);
        TransactionDetail BindDataTransactionDetail(TransactionDataModel model);
        void SetTransactionStatus(TransactionDataModel model, string transactionName);
        string[] UploadPicture(IFormFile Picture, IHostingEnvironment environment, HttpContext sessionContext);
        string base64String(IHostingEnvironment environmentstring, string fileName);
        string ConvertImageToBase64(IFormFile image);
        void DeleteFile(string Path);
    }
}
