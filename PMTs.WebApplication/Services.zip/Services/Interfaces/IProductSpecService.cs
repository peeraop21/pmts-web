﻿using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IProductSpecService
    {
        TransactionDataModel BindDataToModel_ProductSpec(TransactionDataModel model);

        TransactionDataModel BindDataToModel_EditProductSpec(TransactionDataModel model);

        int chkPriority(ProductSpecViewModel model);

        string GetBoardName(ProductSpecViewModel board);

        string GetBoardKIWI(string boardCombine);

        ProductSpecViewModel AddBoardAlt(ProductSpecViewModel model);

        ProductSpecViewModel RemoveBoardAlt(int prior);

        ProductSpecViewModel ShowBoardAlt();

        TransactionDataModel SaveDataToModel_ProductSpec(TransactionDataModel temp, string[] fileName);

        void SaveProductSpec(ProductSpecViewModel board, string picpath);

        void SaveBoardUse(ProductSpecViewModel board);

        void UpdateCostIntoPlantView(TransactionDataModel model);

        void RemoveBoardAlt(string mat);

        void AddBoardAltToDatabase(ProductSpecViewModel board);

        List<ProductSpecViewModel> ComputeRSC(ProductSpecViewModel model);

        List<ProductSpecViewModel> ComputeOneP(ProductSpecViewModel model);

        List<ProductSpecViewModel> ComputeTwoP(ProductSpecViewModel model);

        List<ProductSpecViewModel> ComputeDC(ProductSpecViewModel model);

        List<ProductSpecViewModel> ComputeOther(ProductSpecViewModel model);

        List<ProductSpecViewModel> ComputeTeeth(ProductSpecViewModel model);

        List<ProductSpecViewModel> ComputeWeightAndArea(ProductSpecViewModel model);

        void SetPicData(string[] Base64);

    }
}
