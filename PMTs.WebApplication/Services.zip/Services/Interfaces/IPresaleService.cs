﻿using Microsoft.Extensions.Configuration;
using PMTs.DataAccess.ModelPresale;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IPresaleService
    {
        PresaleViewModel SearchPresale(IConfiguration configuration, PresaleViewModel param);
        MasterDataTransactionModel ImportPresale(IConfiguration configuration, PresaleContext _presaleContext, PresaleViewModel presale);
    }
}
