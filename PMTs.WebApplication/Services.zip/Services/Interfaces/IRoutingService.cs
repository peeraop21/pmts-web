﻿using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.NewProduct;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services.Interfaces
{
    public interface IRoutingService
    {
        void BindDataToModel(PMTsDbContext context, HttpContext httpContext, TransactionDataModel model);
        void UpdateRoutingData(HttpContext httpContext, TransactionDataModel model, TransactionDataModel modelToUpdate);
        RoutingDataModel CalculateCorProp();
        RoutingDataModel CalculateRouting(PMTsDbContext context, string Machine, HttpContext httpContext);
    }
}
