﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class ProductPicService : IProductPicService
    {
        private readonly NewProductService _newProductService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly PMTsDbContext _pMTsDbContext;
        private readonly UserSessionModel _userSessionModel;

        private readonly string _username;
        private readonly string _saleOrg;
        private readonly string _plantCode;

        public ProductPicService(NewProductService newProductService, IHttpContextAccessor httpContextAccessor, PMTsDbContext pMTsDbContext)
        {
            _pMTsDbContext = pMTsDbContext;
            _httpContextAccessor = httpContextAccessor;
            _newProductService = newProductService;

            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
            _username = userSessionModel.UserName;
            _saleOrg = userSessionModel.SaleOrg;
            _plantCode = userSessionModel.PlantCode;
        }

        //base64 to ifromfile
        public TransactionDataModel PicData(IHostingEnvironment environment)
        {
            TransactionDataModel model = new TransactionDataModel();
            try
            {
                string str;
                model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
                if (model.MaterialNo == null)
                {
                    throw new ArgumentException("A problem has been occurred while your picture.");
                    return model;
                }
                if (model.modelProductPicture == null)
                {
                    model.modelProductPicture = new ProductPictureView();
                }

                string[] Picture = ProductPicRepository.LoadPicURL(_pMTsDbContext, model.MaterialNo, _httpContextAccessor.HttpContext);

                if (model.modelProductSpec.PrintMasterPath != null && model.modelProductSpec.PrintMasterPath != "")
                {
                    model.modelProductPicture.Pic_DrawingPath = model.modelProductSpec.PrintMasterPath;
                }

                if (Picture[0] != null)
                {
                    str = "";
                    str = _newProductService.base64String(environment, Picture[0]);

                    model.modelProductPicture.Pic_DrawingPath = str;
                    model.modelProductPicture.Pic_DrawingName = Picture[0];

                }


                if (Picture[1] != null)
                {
                    str = "";
                    str = _newProductService.base64String(environment, Picture[1]);

                    model.modelProductPicture.Pic_PrintPath = str;
                    model.modelProductPicture.Pic_PrintName = Picture[1];

                }

                if (Picture[2] != null)
                {

                    str = "";
                    str = _newProductService.base64String(environment, Picture[2]);

                    model.modelProductPicture.Pic_PalletPath = str;
                    model.modelProductPicture.Pic_PalletName = Picture[2];

                }
                if (Picture[3] != null)
                {

                    str = "";
                    str = _newProductService.base64String(environment, Picture[3]);

                    model.modelProductPicture.Pic_FGPath = str;
                    model.modelProductPicture.Pic_FGName = Picture[3];

                }


                SessionExtentions.SetSession(_httpContextAccessor.HttpContext.Session, "TransactionDataModel", model);
                return model;




            }
            catch (Exception ex)
            {
                model.modelProductPicture = new ProductPictureView();
            }
            return model;

        }

        public void SetPicData(string[,] Base64)
        {
            TransactionDataModel model = new TransactionDataModel();

            try
            {

                model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
                if (model.modelProductPicture == null) model.modelProductPicture = new ProductPictureView();
                model.modelProductPicture.Pic_DrawingPath = Base64[0, 1];
                model.modelProductPicture.Pic_PrintPath = Base64[1, 1];
                model.modelProductPicture.Pic_PalletPath = Base64[2, 1];
                model.modelProductPicture.Pic_FGPath = Base64[3, 1];
                SessionExtentions.SetSession(_httpContextAccessor.HttpContext.Session, "TransactionDataModel", model);

            }
            catch (Exception ex)
            {
                model.modelProductPicture = new ProductPictureView();
            }

        }

        public TransactionDataModel UpdateData(TransactionDataModel model, string MaterialNo, TransactionDataModel Transaction, IHostingEnvironment environment, string Page)
        {
            try
            {
                var path = Path.Combine(environment.WebRootPath, "Picture");
                if (model.modelProductPicture == null)
                {
                    model.modelProductPicture = new ProductPictureView();
                }
                MasterData Master = MasterdataRepository.GetMasterByMaterialNo(_pMTsDbContext, MaterialNo);
                //var UpMasterdata = context.MasterData.Where(x => x.MaterialNo == MaterialNo && x.SaleOrg == sessions.SaleOrg && x.PlantCode == sessions.PlantCode).First();

                if (Master == null)
                {
                    return Transaction;
                }

                if (Master.DiecutPictPath != null)
                {
                    Transaction.modelProductPicture.Pic_DrawingName = Master.DiecutPictPath;
                    Transaction.modelProductPicture.Pic_DrawingPath = _newProductService.base64String(environment, Transaction.modelProductPicture.Pic_DrawingName);

                }

                if (Master.PrintMasterPath != null)
                {
                    Transaction.modelProductPicture.Pic_PrintName = Master.PrintMasterPath;
                    Transaction.modelProductPicture.Pic_PrintPath = _newProductService.base64String(environment, Transaction.modelProductPicture.Pic_PrintName);
                }

                if (Master.PalletizationPath != null)
                {
                    Transaction.modelProductPicture.Pic_PalletName = Master.PalletizationPath;
                    Transaction.modelProductPicture.Pic_PalletPath = _newProductService.base64String(environment, Transaction.modelProductPicture.Pic_PalletName);
                }

                if (Master.FgpicPath != null)
                {
                    Transaction.modelProductPicture.Pic_FGName = Master.FgpicPath;
                    Transaction.modelProductPicture.Pic_FGPath = _newProductService.base64String(environment, Transaction.modelProductPicture.Pic_FGName);

                }

                if (Page == "ProductProp")
                {
                    if (Transaction.EventFlag != "Copy")
                    {
                        if (model.modelProductPicture.Pic_PalletPath == null)
                        {
                            if (Transaction.modelProductPicture.Pic_PalletName != null)
                            {
                                _newProductService.DeleteFile(path + "\\" + Transaction.modelProductPicture.Pic_PalletName);

                            }
                            Master.PalletizationPath = null;
                            Transaction.modelProductPicture.Pic_PalletName = null;
                            Transaction.modelProductPicture.Pic_PalletPath = null;
                        }


                        if (model.modelProductPicture.Pic_FGPath == null)
                        {
                            if (Transaction.modelProductPicture.Pic_FGName != null)
                            {
                                _newProductService.DeleteFile(path + "\\" + Transaction.modelProductPicture.Pic_FGName);

                            }
                            Master.FgpicPath = null;
                            Transaction.modelProductPicture.Pic_FGName = null;
                            Transaction.modelProductPicture.Pic_FGPath = null;
                        }
                    }
                    else
                    {
                        if (model.modelProductPicture.Pic_PalletPath == null)
                        {
                            Master.PalletizationPath = null;
                            Transaction.modelProductPicture.Pic_PalletName = null;
                            Transaction.modelProductPicture.Pic_PalletPath = null;
                        }


                        if (model.modelProductPicture.Pic_FGPath == null)
                        {
                            Master.FgpicPath = null;
                            Transaction.modelProductPicture.Pic_FGName = null;
                            Transaction.modelProductPicture.Pic_FGPath = null;
                        }
                    }

                }
                else
                {
                    if (Transaction.EventFlag != "Copy")
                    {
                        if (model.modelProductPicture.Pic_DrawingPath == null)
                        {
                            if (Transaction.modelProductPicture.Pic_DrawingName != null)
                            {
                                _newProductService.DeleteFile(path + "\\" + Transaction.modelProductPicture.Pic_DrawingName);

                            }
                            Master.DiecutPictPath = null;
                            Transaction.modelProductPicture.Pic_DrawingName = null;
                            Transaction.modelProductPicture.Pic_DrawingPath = null;
                        }
                        if (model.modelProductPicture.Pic_PrintPath == null)
                        {
                            if (Transaction.modelProductPicture.Pic_PrintName != null)
                            {
                                _newProductService.DeleteFile(path + "\\" + Transaction.modelProductPicture.Pic_PrintName);

                            }
                            Master.PrintMasterPath = null;
                            Transaction.modelProductPicture.Pic_PrintName = null;
                            Transaction.modelProductPicture.Pic_PrintPath = null;
                        }


                        if (model.modelProductPicture.Pic_PalletPath == null)
                        {
                            if (Transaction.modelProductPicture.Pic_PalletName != null)
                            {
                                _newProductService.DeleteFile(path + "\\" + Transaction.modelProductPicture.Pic_PalletName);

                            }
                            Master.PalletizationPath = null;
                            Transaction.modelProductPicture.Pic_PalletName = null;
                            Transaction.modelProductPicture.Pic_PalletPath = null;
                        }


                        if (model.modelProductPicture.Pic_FGPath == null)
                        {
                            if (Transaction.modelProductPicture.Pic_FGName != null)
                            {
                                _newProductService.DeleteFile(path + "\\" + Transaction.modelProductPicture.Pic_FGName);

                            }
                            Master.FgpicPath = null;
                            Transaction.modelProductPicture.Pic_FGName = null;
                            Transaction.modelProductPicture.Pic_FGPath = null;
                        }
                    }
                    else
                    {
                        if (model.modelProductPicture.Pic_DrawingPath == null)
                        {

                            Master.DiecutPictPath = null;
                            Transaction.modelProductPicture.Pic_DrawingName = null;
                            Transaction.modelProductPicture.Pic_DrawingPath = null;
                        }
                        if (model.modelProductPicture.Pic_PrintPath == null)
                        {

                            Master.PrintMasterPath = null;
                            Transaction.modelProductPicture.Pic_PrintName = null;
                            Transaction.modelProductPicture.Pic_PrintPath = null;
                        }


                        if (model.modelProductPicture.Pic_PalletPath == null)
                        {

                            Master.PalletizationPath = null;
                            Transaction.modelProductPicture.Pic_PalletName = null;
                            Transaction.modelProductPicture.Pic_PalletPath = null;
                        }


                        if (model.modelProductPicture.Pic_FGPath == null)
                        {

                            Master.FgpicPath = null;
                            Transaction.modelProductPicture.Pic_FGName = null;
                            Transaction.modelProductPicture.Pic_FGPath = null;
                        }
                    }

                }


                Master.DiecutPictPath = Transaction.modelProductPicture.Pic_DrawingName;
                Master.PrintMasterPath = Transaction.modelProductPicture.Pic_PrintName;
                Master.PalletizationPath = Transaction.modelProductPicture.Pic_PalletName;
                Master.FgpicPath = Transaction.modelProductPicture.Pic_FGName;




                _pMTsDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
            }
            return Transaction;

        }

    }


}
