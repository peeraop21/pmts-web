﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.Repository;
using PMTs.WebApplication.Extentions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class LoginService
    {
        public static UserSessionModel LoginUser(HttpContext HttpContext, UserSessionModel model)
        {
            string jsonString = JsonConvert.SerializeObject(model);
            string result = LoginRepository.LoginUser(jsonString);

            UserSessionModel userSessionModel = JsonConvert.DeserializeObject<UserSessionModel>(result);

            return userSessionModel;
        }

    }

}


