﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using PMTs.DataAccess.ModelPresale;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class PresaleService : IPresaleService
    {
        public PresaleViewModel SearchPresale(IConfiguration configuration, PresaleViewModel param)
        {
            return PresaleRepository.GetPresaleBySearch(configuration, param);
        }

        public MasterDataTransactionModel ImportPresale(IConfiguration configuration, PresaleContext _presaleContext, PresaleViewModel presale)
        {

            MasterDataTransactionModel master = new MasterDataTransactionModel();
            PresaleViewModel oPresale = PresaleRepository.GetMasterDataRoutingPresale(configuration, _presaleContext, presale);
            master.tranAction = "Presale";
            master = oPresale.toMasterDataTransactionModel();
            
            return master;
        }

    }
}
