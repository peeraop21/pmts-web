﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class RoutingService : IRoutingService
    {

        IHttpContextAccessor _httpContextAccessor;

        INewProductService _newProductService;

        private readonly string _username;
        private readonly string _saleOrg;
        private readonly string _plantCode;
        
        public RoutingService(IHttpContextAccessor httpContextAccessor, INewProductService newProductService)
        {
            _httpContextAccessor = httpContextAccessor;

            _newProductService = newProductService;

            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
            _username = userSessionModel.UserName;
            _saleOrg = userSessionModel.SaleOrg;
            _plantCode = userSessionModel.PlantCode;
        }

        public void BindDataToModel(PMTsDbContext context, HttpContext httpContext, TransactionDataModel model)
        {
            TransactionDataModel modelSession = SessionExtentions.GetSession<TransactionDataModel>(httpContext.Session, "TransactionDataModel");
            //model.modelRouting = new RoutingViewModel();
            if(model.modelRouting != null)
            {
                model.modelRouting.RoutingDataList = modelSession.modelRouting.RoutingDataList;
            }
            else
            {
                model.modelRouting = new RoutingViewModel();
                model.modelRouting.RoutingDataList = new List<RoutingDataModel>();
            }

            model.MaterialNo = modelSession.MaterialNo;
           
            model.modelRouting.WeightSheetDefault = Math.Round(Convert.ToDecimal(modelSession.modelProductSpec.WeightSh), 2).ToString();

            model.modelRouting.WeightSelectList = new SelectList(new List<SelectListItem> {
                new SelectListItem { Selected = false, Text = Math.Round(Convert.ToDecimal(modelSession.modelProductSpec.WeightSh), 2).ToString(), Value = Math.Round(Convert.ToDecimal(modelSession.modelProductSpec.WeightSh), 2).ToString() },
                new SelectListItem { Selected = false, Text = Math.Round(Convert.ToDecimal(modelSession.modelProductSpec.WeightBox), 2).ToString(), Value = Math.Round(Convert.ToDecimal(modelSession.modelProductSpec.WeightBox), 2).ToString() },
            }, "Value", "Text", 1);

            model.modelRouting.SheetLengthIn = modelSession.modelProductSpec.CutSheetLeng.ToString();
            model.modelRouting.SheetLengthOut = modelSession.modelProductSpec.CutSheetLeng.ToString();
            model.modelRouting.SheetWidthIn = modelSession.modelProductSpec.CutSheetWid.ToString();
            model.modelRouting.SheetWidthOut = modelSession.modelProductSpec.CutSheetWid.ToString();

            model.modelRouting.MachineGroupSelectList = RoutingRepository.GetMachineGroupList(context).OrderBy(o => o.MachineGroup).Select(s => s.MachineGroup).Distinct().Select(sli => new SelectListItem { Value = sli, Text = sli });
            model.modelRouting.InkSelectList = RoutingRepository.GetInkShadeList(context).OrderBy(o => o.Ink).Select(s => s.Ink).Distinct().Select(sli => new SelectListItem { Value = sli, Text = sli });
            model.modelRouting.ShadeSelectList = RoutingRepository.GetInkShadeList(context).OrderBy(o => o.Shade).Select(s => s.Shade).Distinct().Select(sli => new SelectListItem { Value = sli, Text = sli });

            _newProductService.SetTransactionStatus(model, "ProductRouting");
        }

        public void UpdateRoutingData(HttpContext httpContext, TransactionDataModel model, TransactionDataModel modelToUpdate)
        {
            model.modelRouting.RoutingDataList.Where(w => w.SeqNo == modelToUpdate.modelRouting.SeqNo).ToList().ForEach(i =>
            {
                i.GroupMachine = modelToUpdate.modelRouting.GroupMachine;
                i.Machine = modelToUpdate.modelRouting.Machine;
                i.MachineMove = modelToUpdate.modelRouting.MachineMove;
                i.Alternative1 = modelToUpdate.modelRouting.Alternative1;
                i.Alternative2 = modelToUpdate.modelRouting.Alternative2;
                i.Alternative3 = modelToUpdate.modelRouting.Alternative3;
                i.Alternative4 = modelToUpdate.modelRouting.Alternative4;
                i.Alternative5 = modelToUpdate.modelRouting.Alternative5;
                i.Alternative6 = modelToUpdate.modelRouting.Alternative6;
                i.Alternative7 = modelToUpdate.modelRouting.Alternative7;
                i.Alternative8 = modelToUpdate.modelRouting.Alternative8;
                i.NoOpenIn = modelToUpdate.modelRouting.NoOpenIn;
                i.NoOpenOut = modelToUpdate.modelRouting.NoOpenOut;
                i.WeightIn = modelToUpdate.modelRouting.WeightIn;
                i.WeightOut = modelToUpdate.modelRouting.WeightOut;
                i.SheetLengthIn = modelToUpdate.modelRouting.SheetLengthIn;
                i.SheetLengthOut = modelToUpdate.modelRouting.SheetLengthOut;
                i.SheetWidthIn = modelToUpdate.modelRouting.SheetWidthIn;
                i.SheetWidthOut = modelToUpdate.modelRouting.SheetWidthOut;
                i.Coat = modelToUpdate.modelRouting.Coat;
                i.PaperRollWidth = modelToUpdate.modelRouting.PaperRollWidth;
                i.Cut = modelToUpdate.modelRouting.Cut;
                i.Trim = modelToUpdate.modelRouting.Trim;
                i.PercentTrim = modelToUpdate.modelRouting.PercentTrim;
                i.TearTape = modelToUpdate.modelRouting.TearTape;
                i.LineQtyPerBox = modelToUpdate.modelRouting.LineQtyPerBox;
                i.MarginForPaper = modelToUpdate.modelRouting.MarginForPaper;
                i.Ink1 = modelToUpdate.modelRouting.Ink1;
                i.Ink2 = modelToUpdate.modelRouting.Ink2;
                i.Ink3 = modelToUpdate.modelRouting.Ink3;
                i.Shade1 = modelToUpdate.modelRouting.Shade1;
                i.Shade2 = modelToUpdate.modelRouting.Shade2;
                i.Shade3 = modelToUpdate.modelRouting.Shade3;
                i.Area1 = modelToUpdate.modelRouting.Area1;
                i.Area2 = modelToUpdate.modelRouting.Area2;
                i.Area3 = modelToUpdate.modelRouting.Area3;
                i.PrintingPlateNo = modelToUpdate.modelRouting.PrintingPlateNo;
                i.CuttingDieNo = modelToUpdate.modelRouting.CuttingDieNo;
                i.MylaNo = modelToUpdate.modelRouting.MylaNo;
                i.PrintingPlateType = modelToUpdate.modelRouting.PrintingPlateType;
                i.JoinToMaterialNo = modelToUpdate.modelRouting.JoinToMaterialNo;
                i.SperateToMaterialNo = modelToUpdate.modelRouting.SperateToMaterialNo;
                i.Remark = modelToUpdate.modelRouting.Remark;
                i.MachineGroupSelect = modelToUpdate.modelRouting.MachineGroupSelect;
            });

            if (modelToUpdate.modelRouting.RemarkAttachFileStatus == 0)
            {
                model.modelRouting.RoutingDataList.First(i => i.SeqNo == modelToUpdate.modelRouting.SeqNo).RemarkImageFile = null;
                model.modelRouting.RoutingDataList.First(i => i.SeqNo == modelToUpdate.modelRouting.SeqNo).RemarkImageFileName = null;
            }
        }

        public RoutingDataModel CalculateCorProp()
        {

            return new RoutingDataModel();
        }

        public RoutingDataModel CalculateRouting(PMTsDbContext context, string Machine, HttpContext httpContext)
        {
            RoutingDataModel ret = new RoutingDataModel();

            try
            {            
                CorConfig corConfig = RoutingRepository.GetCorConfigByName(context, Machine);
                TransactionDataModel tran = SessionExtentions.GetSession<TransactionDataModel>(httpContext.Session, "TransactionDataModel");
                TblFlute flute = FluteRepository.GetFluteByFute(context, tran.modelProductSpec.Flute, tran.PlantCode);
                List<PaperWidth> RollWidth = RoutingRepository.GetPaperWidths(context);

                int sheetIn_W = (tran.modelProductSpec.CutSheetWid).GetValueOrDefault();
                int maxCut = corConfig.CutOff;
                int trimWaste = (int)(flute.MinTrim);
                int? sizeWidth = 0;
                int pageMin = corConfig.MinOut;
                int pageMax = corConfig.MaxOut;
                //Mintrim

                if (corConfig.Mintrim) //Min Trim
                {
                    List<string> PaperItem = RoutingRepository.GetPaperItemByMaterialNo(context, tran.MaterialNo);
                    PaperGrad PaperGrad;
                    int GroupItem = 10000;;
                    double[,] RollSize = new double[6, 4];
                    int X, M;
                    // Comming Soon
                    foreach (var Item in PaperItem)
                    {
                        PaperGrad = RoutingRepository.GetPaperGradByGrade(context, Item);
                        if (PaperGrad.Group < GroupItem)
                        {
                            GroupItem = PaperGrad.Group;
                        }
                    }
                    ret.Trim = "1000";//กำหนดค่าหลอกเพื่อไปเปรียบเทียบกับ % Trimน้อยสุด

                    var Roll =  RollWidth.FirstOrDefault(w => w.Group1 == pageMin || w.Group2 == pageMin || w.Group3 == pageMin || w.Group4 == pageMin);

                    if(Roll != null)
                    {
                        pageMin = GroupItem == 1 ? Convert.ToInt32(Roll.Group1) : GroupItem == 2 ? Convert.ToInt32(Roll.Group2) : GroupItem == 3 ? Convert.ToInt32(Roll.Group3) : Convert.ToInt32(Roll.Group4);

                    }

                    //for (X = 0; X < RollWidth.Count; X++)
                    //{
                        
                    //        if (Convert.ToInt32(RollWidth[X].Group1) > pageMin) break;
                    //        if (Convert.ToInt32(RollWidth[X].Group1) == pageMin)
                    //        {
                    //            pageMin = GroupItem == 1 ? Convert.ToInt32(RollWidth[X].Group1) : GroupItem == 2 ? Convert.ToInt32(RollWidth[X].Group2) : GroupItem == 3 ? Convert.ToInt32(RollWidth[X].Group3) : Convert.ToInt32(RollWidth[X].Group4);
                    //            break;
                    //        }
                        
                    //}

                    for (X = 0; X < maxCut; X++) //คำนวนหน้ากว้าง + Standard Trim
                    {
                        RollSize[X, 1] = (sheetIn_W * (X+1)) + trimWaste;
                        if (RollSize[X, 1] < pageMin) RollSize[X, 0] = pageMin;   //น้อยกว่าหน้าน้อยสุด
                        else if (RollSize[X, 1] > pageMax) RollSize[X, 0] = 0;     //มากกว่าหน้าสูงสุด
                        else
                        {
                            
                                switch (GroupItem)
                                {
                                    case 1:
                                    for (M = 0; M < RollWidth.Count; M++)
                                    {
                                        if (Convert.ToInt32(RollWidth[M].Group1) >= pageMin && Convert.ToInt32(RollWidth[M].Group1) <= pageMax)
                                        {
                                            if (RollSize[X, 1] <= Convert.ToInt32(RollWidth[M].Group1))
                                            {
                                                RollSize[X, 0] = Convert.ToInt32(RollWidth[M].Group1);
                                                break;
                                            }
                                        }
                                    }
                                        break;
                                    case 2:
                                    for (M = 0; M < RollWidth.Count; M++)
                                    {
                                        if (Convert.ToInt32(RollWidth[M].Group2) >= pageMin && Convert.ToInt32(RollWidth[M].Group2) <= pageMax)
                                        {
                                            if (RollSize[X, 1] <= Convert.ToInt32(RollWidth[M].Group2))
                                            {
                                                RollSize[X, 0] = Convert.ToInt32(RollWidth[M].Group2);
                                                break;
                                            }
                                        }
                                    }
                                        break;
                                    case 3:
                                    for (M = 0; M < RollWidth.Count; M++)
                                    {
                                        if (Convert.ToInt32(RollWidth[M].Group3) >= pageMin && Convert.ToInt32(RollWidth[M].Group3) <= pageMax)
                                        {
                                            if (RollSize[X, 1] <= Convert.ToInt32(RollWidth[M].Group3))
                                            {
                                                RollSize[X, 0] = Convert.ToInt32(RollWidth[M].Group3);
                                                break;
                                            }
                                        }
                                    }
                                        break;
                                    case 4:
                                    for (M = 0; M < RollWidth.Count; M++)
                                    {
                                        if (Convert.ToInt32(RollWidth[M].Group4) >= pageMin && Convert.ToInt32(RollWidth[M].Group4) <= pageMax)
                                        {
                                            if (RollSize[X, 1] <= Convert.ToInt32(RollWidth[M].Group4))
                                            {
                                                RollSize[X, 0] = Convert.ToInt32(RollWidth[M].Group4);
                                                break;
                                            }
                                        }
                                    }
                                        break;
                                    
                                }
                                
                            

                            if (RollSize[X, 0] > 0)
                            {
                                RollSize[X, 2] = (RollSize[X, 0] - (RollSize[X, 1] - trimWaste)) / RollSize[X, 0] * 100; //คำนวน % Trim

                                if (Convert.ToInt32(ret.Trim) >= Math.Round(RollSize[X, 3], 2))//เลือก % Trim น้อยที่สุด
                                {
                                    ret.PaperRollWidth = RollSize[X, 0].ToString();
                                    ret.Cut = (X+1).ToString();
                                    ret.Trim = (RollSize[X, 0] - RollSize[X, 1] + trimWaste).ToString(); //เศษ
                                    ret.PercentTrim = (Math.Round(RollSize[X, 2], 2)).ToString();
                                }
                            }
                        }
                    }

                }
                else //Max Out
                {
                    sizeWidth = (sheetIn_W * maxCut) + trimWaste;

                    //ตรวจหาหน้ากว้างสุดและแคบสุด
                    if (sizeWidth < pageMin)
                    {
                        ret.PaperRollWidth = pageMin.ToString();                                //Paper Width
                        ret.Cut = "1";                                                          //จำนวนตัด
                        ret.Trim = (pageMin - sheetIn_W).ToString();                            //เศษตัดริม
                        ret.PercentTrim = Math.Round((Double.Parse(ret.Trim) / Convert.ToDouble(pageMin) * 100), 2).ToString();   //% Waste
                        return ret;
                    }

                    /////////////////////////////////////////////////////////////

                    if (sheetIn_W + trimWaste > pageMax)
                    {
                        ret.PaperRollWidth = pageMax.ToString();                                //Paper Width
                        ret.Cut = maxCut.ToString();                                            //จำนวนตัด
                        ret.Trim = (pageMax - sheetIn_W * 1).ToString();                        //เศษตัดริม
                        ret.PercentTrim = Math.Round((Double.Parse(ret.Trim) / Convert.ToDouble(pageMax) * 100), 2).ToString();   //% Waste
                        return ret;
                    }

                    /////////////////////////////////////////////////////////////

                    int k = maxCut;
                    for (k = maxCut; k > 0; k--)
                    {
                        if (sizeWidth > pageMax)
                        {
                            sizeWidth = sheetIn_W * k + trimWaste;
                            if (sizeWidth <= pageMax)
                            {
                                break;
                            }
                        }
                        else break;
                    }

                    for (int i = 0; i < pageMax; i++)
                    {
                        if (RollWidth[i].Group2 >= sizeWidth)
                        {
                            ret.PaperRollWidth = RollWidth[i].Group2.ToString();                                        //Paper Width
                            ret.Cut = k.ToString();                                                                     //จำนวนตัด
                            ret.Trim = (RollWidth[i].Group2 - sheetIn_W * k).ToString();                                //เศษตัดริม
                            ret.PercentTrim = Math.Round((Double.Parse(ret.Trim) / Convert.ToDouble(RollWidth[i].Group2) * 100), 2).ToString();           //% Waste
                            break;
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }          

            return ret;

        }
    }
}
