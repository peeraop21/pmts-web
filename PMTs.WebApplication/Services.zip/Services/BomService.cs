﻿using Microsoft.AspNetCore.Http;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.Repository;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class BomService : IBomService
    {
        public BOMViewModel GetMatParent(PMTsDbContext context, string txtSearch, string ddlSearch)
        {
            BOMViewModel model = new BOMViewModel();
            model.lstBomStructs = BomRepository.GetBomStructsByMatOrPC(context, txtSearch, ddlSearch);
            return model;
        }

        public BOMViewModel GetMatChild(PMTsDbContext context, BOMViewModel model)
        {
            model.lstMasterData = new List<MasterData>();
            model.lstMasterData = BomRepository.GetMasterDataListChild(context, model);
            return model;
        }

        public BOMViewModel GetBomStruct(PMTsDbContext context, string materialNo)
        {
            BOMViewModel model = new BOMViewModel();
            model.lstBomStructs = BomRepository.GetBomStructsByMat(context, materialNo);
            return model;
        }

    }
}
