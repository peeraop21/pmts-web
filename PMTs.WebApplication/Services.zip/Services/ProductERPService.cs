﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class ProductERPService : IProductERPService
    {
        public TransactionDataModel ProductERPData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel model)
        {

            SessionsModel sessions = new SessionsModel
            {
                UserName = sessionContext.Session.GetString("username"),
                SaleOrg = sessionContext.Session.GetString("SALE_ORG"),
                PlantCode = sessionContext.Session.GetString("PLANT_CODE"),
            };
            model.modelProductERP = new ProductERPPlantViewModel();

            //GetPlant
            model.modelProductERP.PlantList = ProductERPRepository.GetListCompany(context).Select(s => new SelectListItem() { Value = s.Plant.ToString(), Text = s.Plant.ToString() });

            model.modelProductERP.PurchCode = ProductERPRepository.GetPuchCode(context, sessions.PlantCode);

            model.modelProductERP.ModelList = new List<PlantView>();

            var Material_no = model.MaterialNo;

            model.modelProductERP.ModelList = ProductERPRepository.GetPlantList(context, Material_no);

            //Sale View 
            model.modelProductERPSale = new ProductERPSaleViewModel();
            model.modelProductERPSale.SaleOrgList = ProductERPRepository.GetListSaleorg(context).Select(s => new SelectListItem() { Value = s.SaleOrg.ToString(), Text = s.SaleOrg.ToString() });

            model.modelProductERPSale.ModelListSale = ProductERPRepository.GetSaleList(context, Material_no);

            model.modelProductERPPurchase = new ProductERPPurchaseViewModel();
            //model.modelProductERPPurchase = NewProductService.BindDataPurchaseByMatNo(context, Material_no); // Test
            return model;
        }

        public  TransactionDataModel PlantViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PlantData) //qqqqq
        {
            TransactionDataModel model = new TransactionDataModel();

            try
            {

                model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
                model.modelProductERP = new ProductERPPlantViewModel();
                model.modelProductERP = PlantData.modelProductERP;
            }
            catch (Exception ex)
            {
                model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
                model.modelProductERP = new ProductERPPlantViewModel();
            }
            return model;
        }

        public bool ChkPlantMat(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PlantData, string btnSave)
        {
            //  TransactionDataModel model = new TransactionDataModel();
            bool statusDupicate = true;
            var Material_no = PlantData.MaterialNo;
            var result = context.PlantView.Where(x => x.MaterialNo == Material_no && x.Plant == PlantData.modelProductERP.Plant && x.PDISStatus !="X").FirstOrDefault();
            if (result == null)
            {
                statusDupicate = false;
            }
            return statusDupicate;
        }

        public string GenPurch(PMTsDbContext context, string Plant)
        {

            var result = (from x in context.CompanyProfile
                          where x.Plant == Plant
                          select x).FirstOrDefault();

            return result.PurchasGrp.Trim();
        }

        public TransactionDataModel SavePlantViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PlantData, string btnSave)
        {

            //Check EOF PlantView ซ้ำหรือไม่
            // string alerttxt;
            TransactionDataModel model = new TransactionDataModel();
            var Material_no = PlantData.MaterialNo;
            var result = context.PlantView.Where(x => x.MaterialNo == Material_no && x.Plant == PlantData.modelProductERP.Plant).FirstOrDefault();

            if (result == null)
            {
                //check routing Ship
                var Chkship = context.Routing.Where(x => (x.MaterialNo == Material_no && x.ShipBlk == true) || (x.MaterialNo == Material_no && x.SemiBlk == true)).Count();

                string Ship_Blk = "X";
                string Ship = "X";

                var Masterdata = context.MasterData.Where(x => x.MaterialNo == Material_no).FirstOrDefault();
                MasterData master = new MasterData
                {
                    TranStatus = Masterdata.TranStatus,
                    SapStatus = Masterdata.SapStatus
                };
                string PDIS_Status = "M";
                bool Tran_Status = false;
                bool SAP_Status = true;
                string PDIST = "M";
                if (master.TranStatus == false && master.SapStatus == false)
                {
                    PDIS_Status = "C";
                    Tran_Status = false;
                    SAP_Status = false;
                    PDIST = "C";
                }
                else if ((master.TranStatus == null || master.SapStatus == null))
                {
                    PDIS_Status = "C";
                    Tran_Status = false;
                    SAP_Status = false;
                    PDIST = "C";
                }

                if (Chkship == 0)
                {
                    Ship_Blk = "";
                    Ship = "";
                }

                // add new record
                PlantView plantV = new PlantView
                {
                    MaterialNo = Material_no, // ค่าตั้งต้นก่อน
                    Plant = PlantData.modelProductERP.Plant,
                    PurchCode = PlantData.modelProductERP.PurchCode,
                    StdTotalCost = PlantData.modelProductERP.StdtotalCost,
                    StdMovingCost = 0,
                    StdFC = 0,
                    StdVC = 0,
                    ShipBlk = Ship_Blk,
                    PDISStatus = PDIS_Status,
                    TranStatus = Tran_Status,
                    SAPStatus = SAP_Status

                };
                // Add New record PlantView

                ProductERPRepository.SavePlantView(context, plantV);


                //Update masterdata
                if (Tran_Status == true)
                {
                    switch (PDIS_Status)
                    {
                        case "C":
                            if (SAP_Status = true)
                            {
                                PDIS_Status = "D";
                                Tran_Status = false;
                            }
                            else
                            {
                                Tran_Status = false;
                            }
                            break;
                        case "D":
                            Tran_Status = false;
                            break;
                        case "M":
                            Tran_Status = false;
                            break;
                        case "X":
                            if (SAP_Status = false)
                            {
                                Tran_Status = true;
                                SAP_Status = true;
                            }
                            else
                            {
                                Tran_Status = false;
                            }
                            break;
                        case null:
                            SAP_Status = false;
                            PDIS_Status = "C";
                            Tran_Status = false;

                            break;
                    }
                    ProductERPRepository.SaveMasterData(context, Material_no, Tran_Status, PDIS_Status, SAP_Status);
                }


            }
            else
            {
                //ค่าซ้ำ    
                UpdatePlantViewData(context, sessionContext, PlantData, btnSave);

            }
            SessionsModel sessions = new SessionsModel
            {
                UserName = sessionContext.Session.GetString("username"),
                SaleOrg = sessionContext.Session.GetString("SALE_ORG"),
                PlantCode = sessionContext.Session.GetString("PLANT_CODE"),
            };

            // TransactionDataModel model = new TransactionDataModel();
            model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
            model.modelProductERP = new ProductERPPlantViewModel();
            //   model.modelProductProp = Propdata.modelProductProp;
            // model.modelProductProp = new ProductPropViewModel();
            return model;
        }
        public TransactionDataModel UpdatePlantViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PlantData, String UpdateBtn)
        {
            //Check EOF PlantView ซ้ำหรือไม่
            // string alerttxt;
            TransactionDataModel model = new TransactionDataModel();
            var Material_no = PlantData.MaterialNo;
            var result = context.PlantView.Where(x => x.MaterialNo == Material_no && x.Plant == PlantData.modelProductERP.Plant).FirstOrDefault();

            var Chkship = context.Routing.Where(x => (x.MaterialNo == Material_no && x.ShipBlk == true) || (x.MaterialNo == Material_no && x.SemiBlk == true)).Count();

            string Ship_Blk = "X";
            string Ship = "X";

            var Masterdata = context.MasterData.Where(x => x.MaterialNo == Material_no).FirstOrDefault();
            MasterData master = new MasterData
            {
                TranStatus = Masterdata.TranStatus,
                SapStatus = Masterdata.SapStatus
            };
            string PDIS_Status = "M";
            bool Tran_Status = false;
            bool SAP_Status = true;
            string PDIST = "M";
            if (master.TranStatus == false && master.SapStatus == false)
            {
                PDIS_Status = "C";
                Tran_Status = false;
                SAP_Status = false;
                PDIST = "C";
            }
            else if ((master.TranStatus == null || master.SapStatus == null))
            {
                PDIS_Status = "C";
                Tran_Status = false;
                SAP_Status = false;
                PDIST = "C";
            }

            if (Chkship == 0)
            {
                Ship_Blk = "";
                Ship = "";
            }

            // add new record
            PlantView plantV = new PlantView
            {
                MaterialNo = Material_no, // ค่าตั้งต้นก่อน
                Plant = PlantData.modelProductERP.Plant,
                PurchCode = PlantData.modelProductERP.PurchCode,
                StdTotalCost = PlantData.modelProductERP.StdtotalCost,
                StdMovingCost = 0,
                StdFC = 0,
                StdVC = 0,
                ShipBlk = Ship_Blk,
                PDISStatus = PDIS_Status,
                TranStatus = Tran_Status,
                SAPStatus = SAP_Status

            };







            ProductERPRepository.UpdatePlantView(context, plantV);

            //Update masterdata
            if (Tran_Status == true)
            {
                switch (PDIS_Status)
                {
                    case "C":
                        if (SAP_Status = true)
                        {
                            PDIS_Status = "D";
                            Tran_Status = false;
                        }
                        else
                        {
                            Tran_Status = false;
                        }
                        break;
                    case "D":
                        Tran_Status = false;
                        break;
                    case "M":
                        Tran_Status = false;
                        break;
                    case "X":
                        if (SAP_Status = false)
                        {
                            Tran_Status = true;
                            SAP_Status = true;
                        }
                        else
                        {
                            Tran_Status = false;
                        }
                        break;
                    case null:
                        SAP_Status = false;
                        PDIS_Status = "C";
                        Tran_Status = false;

                        break;
                }
            }

            SessionsModel sessions = new SessionsModel
            {
                UserName = sessionContext.Session.GetString("username"),
                SaleOrg = sessionContext.Session.GetString("SALE_ORG"),
                PlantCode = sessionContext.Session.GetString("PLANT_CODE"),
            };

            // TransactionDataModel model = new TransactionDataModel();
            model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
            model.modelProductERP = new ProductERPPlantViewModel();
            //   model.modelProductProp = Propdata.modelProductProp;
            // model.modelProductProp = new ProductPropViewModel();
            return model;
        }

        public TransactionDataModel DeletePlantViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel model, String btnDeleteERP)
        {
            //   TransactionDataModel model = new TransactionDataModel();
            var Material_no = model.MaterialNo;
            PlantView ProductPlant = new PlantView
            {
                MaterialNo = Material_no, // ค่าตั้งต้นก่อน
                PurchCode = model.modelProductERP.PurchCode,
                StdTotalCost = model.modelProductERP.StdtotalCost,
                Plant = model.modelProductERP.Plant

            };
            //ProductERPRepository.UpdatePlantView(context, ProductPlant);
            ProductERPRepository.DeletePlantView(context, ProductPlant);
            SessionsModel sessions = new SessionsModel
            {
                UserName = sessionContext.Session.GetString("username"),
                SaleOrg = sessionContext.Session.GetString("SALE_ORG"),
                PlantCode = sessionContext.Session.GetString("PLANT_CODE"),
            };


            model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
            //////model.modelProductERP = new ProductERPPlantViewModel();
            //   model.modelProductProp = Propdata.modelProductProp;
            // model.modelProductProp = new ProductPropViewModel();
            return model;
        }

        public TransactionDataModel SaleViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData)
        {
            TransactionDataModel model = new TransactionDataModel();

            try
            {

                model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
                model.modelProductERPSale = new ProductERPSaleViewModel();
                model.modelProductERPSale = SaleData.modelProductERPSale;

            }
            catch (Exception ex)
            {
                model.modelProductERPSale = new ProductERPSaleViewModel();
            }
            return model;
        }

        public bool ChkSaleMat(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData, string btnSave)
        {
            bool statusDupicate = true;
            var Material_no = SaleData.MaterialNo;
            //   var result = context.SalesView.Where(x => x.MaterialNo == Material_no && x.SaleOrg == SaleData.modelProductERPSale.SaleOrg).FirstOrDefault();

            var result = context.SalesView.Where(x => x.MaterialNo == Material_no && x.SaleOrg == SaleData.modelProductERPSale.SaleOrg && x.PdisStatus != "X").FirstOrDefault();
            if (result == null)
            {
                statusDupicate = false;
            }
            return statusDupicate;
        }
        public TransactionDataModel SaveSaleViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData, string btnSave)
        {
            TransactionDataModel model = new TransactionDataModel();
            //Check EOF PlantView ซ้ำหรือไม่
            // string alerttxt;
            var Material_no = SaleData.MaterialNo;
            var result = context.SalesView.Where(x => x.MaterialNo == Material_no && x.SaleOrg == SaleData.modelProductERPSale.SaleOrg).FirstOrDefault();

            if (result == null)
            {


                //check routing Ship
                var Chkship = context.Routing.Where(x => (x.MaterialNo == Material_no && x.ShipBlk == true) || (x.MaterialNo == Material_no && x.SemiBlk == true)).Count();

                string Ship_Blk = "X";
                string Ship = "X";

                var Masterdata = context.MasterData.Where(x => x.MaterialNo == Material_no).FirstOrDefault();
                MasterData master = new MasterData
                {
                    TranStatus = Masterdata.TranStatus,
                    SapStatus = Masterdata.SapStatus
                };
                string PDIS_Status = "M";
                bool Tran_Status = false;
                bool SAP_Status = true;
                string PDIST = "M";


                if (master.TranStatus == false && master.SapStatus == false)
                {
                    PDIS_Status = "C";
                    Tran_Status = false;
                    SAP_Status = false;
                    PDIST = "C";
                }
                else if ((master.TranStatus == null || master.SapStatus == null))
                {
                    PDIS_Status = "C";
                    Tran_Status = false;
                    SAP_Status = false;
                    PDIST = "C";
                }

                if (Chkship == 0)
                {
                    Ship_Blk = "";
                    Ship = "";
                }

                // add new record
                SalesView saleV = new SalesView
                {
                    MaterialNo = Material_no, // ค่าตั้งต้นก่อน
                    SaleOrg = SaleData.modelProductERPSale.SaleOrg,
                    Channel = SaleData.modelProductERPSale.Channel,
                    DevPlant = SaleData.modelProductERPSale.DevPlant,
                    CustCode = SaleData.modelProductERPSale.CustCode,
                    MinQty = SaleData.modelProductERPSale.MinQty,
                    OrderType = SaleData.modelProductERPSale.OrderType,
                    PdisStatus = PDIS_Status,
                    TranStatus = Tran_Status,
                    SapStatus = SAP_Status

                };
                // Add New record PlantView

                ProductERPRepository.SaveSaleView(context, saleV);


                //Update masterdata
                if (Tran_Status == true)
                {
                    switch (PDIS_Status)
                    {
                        case "C":
                            if (SAP_Status = true)
                            {
                                PDIS_Status = "D";
                                Tran_Status = false;
                            }
                            else
                            {
                                Tran_Status = false;
                            }
                            break;
                        case "D":
                            Tran_Status = false;
                            break;
                        case "M":
                            Tran_Status = false;
                            break;
                        case "X":
                            if (SAP_Status = false)
                            {
                                Tran_Status = true;
                                SAP_Status = true;
                            }
                            else
                            {
                                Tran_Status = false;
                            }
                            break;
                        case null:
                            SAP_Status = false;
                            PDIS_Status = "C";
                            Tran_Status = false;
                            break;
                    }
                    ProductERPRepository.SaveMasterData(context, Material_no, Tran_Status, PDIS_Status, SAP_Status);
                }


            }
            else
            {
                //ค่าซ้ำ    
                UpdateSaleViewData(context, sessionContext, SaleData, btnSave);

            }
            SessionsModel sessions = new SessionsModel
            {
                UserName = sessionContext.Session.GetString("username"),
                SaleOrg = sessionContext.Session.GetString("SALE_ORG"),
                PlantCode = sessionContext.Session.GetString("PLANT_CODE"),
            };

            // TransactionDataModel model = new TransactionDataModel();
            model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
            model.modelProductERP = new ProductERPPlantViewModel();
            //   model.modelProductProp = Propdata.modelProductProp;
            // model.modelProductProp = new ProductPropViewModel();
            return model;
        }

        public TransactionDataModel UpdateSaleViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData, String UpdateBtn)
        {
            TransactionDataModel model = new TransactionDataModel();
            //Check EOF PlantView ซ้ำหรือไม่
            // string alerttxt;
            var Material_no = SaleData.MaterialNo;
            var result = context.SalesView.Where(x => x.MaterialNo == Material_no && x.SaleOrg == SaleData.modelProductERPSale.SaleOrg && x.Channel==SaleData.modelProductERPSale.Channel).FirstOrDefault();

            if (result != null)
            {


                //check routing Ship
                var Chkship = context.Routing.Where(x => (x.MaterialNo == Material_no && x.ShipBlk == true) || (x.MaterialNo == Material_no && x.SemiBlk == true)).Count();

                string Ship_Blk = "X";
                string Ship = "X";

                var Masterdata = context.MasterData.Where(x => x.MaterialNo == Material_no).FirstOrDefault();
                MasterData master = new MasterData
                {
                    TranStatus = Masterdata.TranStatus,
                    SapStatus = Masterdata.SapStatus
                };
                string PDIS_Status = "M";
                bool Tran_Status = false;
                bool SAP_Status = true;
                string PDIST = "M";


                if (master.TranStatus == false && master.SapStatus == false)
                {
                    PDIS_Status = "C";
                    Tran_Status = false;
                    SAP_Status = false;
                    PDIST = "C";
                }
                else if ((master.TranStatus == null || master.SapStatus == null))
                {
                    PDIS_Status = "C";
                    Tran_Status = false;
                    SAP_Status = false;
                    PDIST = "C";
                }

                if (Chkship == 0)
                {
                    Ship_Blk = "";
                    Ship = "";
                }

                // add new record
                SalesView saleV = new SalesView
                {
                    MaterialNo = Material_no, // ค่าตั้งต้นก่อน
                    SaleOrg = SaleData.modelProductERPSale.SaleOrg,
                    Channel = SaleData.modelProductERPSale.Channel,
                    DevPlant = SaleData.modelProductERPSale.DevPlant,
                    CustCode = SaleData.modelProductERPSale.CustCode,
                    MinQty = SaleData.modelProductERPSale.MinQty,
                    OrderType = SaleData.modelProductERPSale.OrderType,
                    PdisStatus = PDIS_Status,
                    TranStatus = Tran_Status,
                    SapStatus = SAP_Status

                };
                // Add New record PlantView

                ProductERPRepository.UpdateSaleView(context, saleV);


                //Update masterdata
                if (Tran_Status == true)
                {
                    switch (PDIS_Status)
                    {
                        case "C":
                            if (SAP_Status = true)
                            {
                                PDIS_Status = "D";
                                Tran_Status = false;
                            }
                            else
                            {
                                Tran_Status = false;
                            }
                            break;
                        case "D":
                            Tran_Status = false;
                            break;
                        case "M":
                            Tran_Status = false;
                            break;
                        case "X":
                            if (SAP_Status = false)
                            {
                                Tran_Status = true;
                                SAP_Status = true;
                            }
                            else
                            {
                                Tran_Status = false;
                            }
                            break;
                        case null:
                            SAP_Status = false;
                            PDIS_Status = "C";
                            Tran_Status = false;
                            break;
                    }
                }

                //     ProductERPRepository.SaveMasterData(context,Material_no, Tran_Status, PDIS_Status, SAP_Status);
            }
            else
            {
                //ค่าซ้ำ                

            }
            SessionsModel sessions = new SessionsModel
            {
                UserName = sessionContext.Session.GetString("username"),
                SaleOrg = sessionContext.Session.GetString("SALE_ORG"),
                PlantCode = sessionContext.Session.GetString("PLANT_CODE"),
            };

            // TransactionDataModel model = new TransactionDataModel();
            model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
            model.modelProductERP = new ProductERPPlantViewModel();
            //   model.modelProductProp = Propdata.modelProductProp;
            // model.modelProductProp = new ProductPropViewModel();
            return model;
        }

        public TransactionDataModel DeleteSaleViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel SaleData, String UpdateBtn)
        {
            TransactionDataModel model = new TransactionDataModel();


            model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
            //Check EOF PlantView ซ้ำหรือไม่
            // string alerttxt;
            var Material_no = SaleData.MaterialNo;
            SalesView saleV = new SalesView
            {
                MaterialNo = Material_no, // ค่าตั้งต้นก่อน
                SaleOrg = SaleData.modelProductERPSale.SaleOrg,
                Channel = SaleData.modelProductERPSale.Channel,
                DevPlant = SaleData.modelProductERPSale.DevPlant,
                CustCode = SaleData.modelProductERPSale.CustCode,
                MinQty = SaleData.modelProductERPSale.MinQty,
                OrderType = SaleData.modelProductERPSale.OrderType,
                PdisStatus = "X",
                TranStatus = false

            };
            // Add New record PlantView

            ProductERPRepository.DeleteSaleView(context, saleV);

            return model;
        }

        public TransactionDataModel PurchaseViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PurchaseData)
        {
            TransactionDataModel model = new TransactionDataModel();
            try
            {

                model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
                model.modelProductERPPurchase = new ProductERPPurchaseViewModel();
                model.modelProductERPPurchase = PurchaseData.modelProductERPPurchase;

            }
            catch (Exception ex)
            {
                model.modelProductERPPurchase = new ProductERPPurchaseViewModel();
            }
            return model;
        }

        public TransactionDataModel SavePurchaseViewData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel PurData)
        {
            TransactionDataModel model = new TransactionDataModel();
            //Check EOF PlantView ซ้ำหรือไม่
            // string alerttxt;
            var Material_no = PurData.MaterialNo;
            var PurTxt1 = PurData.modelProductERPPurchase.PurTxt1;
            var PurTxt2 = PurData.modelProductERPPurchase.PurTxt2;
            var PurTxt3 = PurData.modelProductERPPurchase.PurTxt3;
            var PurTxt4 = PurData.modelProductERPPurchase.PurTxt4;

            ProductERPRepository.SavePurMasterData(context, Material_no, PurTxt1, PurTxt2, PurTxt3, PurTxt4);

            // TransactionDataModel model = new TransactionDataModel();
            model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
            model.modelProductERP = new ProductERPPlantViewModel();
            //   model.modelProductProp = Propdata.modelProductProp;
            // model.modelProductProp = new ProductPropViewModel();
            return model;
        }

    }
}
