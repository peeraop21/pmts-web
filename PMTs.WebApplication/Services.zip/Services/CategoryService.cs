﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PMTs.DataAccess.ModelsNew;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.DataAccess.Repository.Interfaces;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PMTs.WebApplication.Services
{
    public class CategoryService : ICategoryService
    {

        IHttpContextAccessor _httpContextAccessor;

        private readonly IKindOfProductGroupAPIRepository _kindOfProductGroupAPIRepository;
        private readonly IKindOfProductAPIRepository _kindOfProductAPIRepository;
        private readonly IProcessCostAPIRepository _processCostAPIRepository;
        private readonly IProductTypeAPIRepository _productTypeAPIRepository;
        private readonly IMaterialTypeAPIRepository _materialTypeAPIRepository;
        private readonly IUnitMaterialAPIRepository _unitMaterialAPIRepository;
        private readonly IHierarchyLv2APIRepository _hierarchyLv2APIRepository;

        private readonly string _username;
        private readonly string _saleOrg;
        private readonly string _plantCode; 

        public CategoryService(IHttpContextAccessor httpContextAccessor,
            IKindOfProductGroupAPIRepository kindOfProductGroupAPIRepository,
            IKindOfProductAPIRepository kindOfProductAPIRepository,
            IProcessCostAPIRepository processCostAPIRepository,
            IProductTypeAPIRepository productTypeAPIRepository,
            IMaterialTypeAPIRepository materialTypeAPIRepository,
            IUnitMaterialAPIRepository unitMaterialAPIRepository,
            IHierarchyLv2APIRepository hierarchyLv2APIRepository)
        {
            _httpContextAccessor = httpContextAccessor;
            _kindOfProductGroupAPIRepository = kindOfProductGroupAPIRepository;
            _kindOfProductAPIRepository = kindOfProductAPIRepository;
            _processCostAPIRepository = processCostAPIRepository;
            _productTypeAPIRepository = productTypeAPIRepository;
            _materialTypeAPIRepository = materialTypeAPIRepository;
            _unitMaterialAPIRepository = unitMaterialAPIRepository;
            _hierarchyLv2APIRepository = hierarchyLv2APIRepository;

            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
            _username = userSessionModel.UserName;
            _saleOrg = userSessionModel.SaleOrg;
            _plantCode = userSessionModel.PlantCode;
    }

        public TransactionDataModel BindDataToModelCategoriesCreate(TransactionDataModel model, string ActionTran)
        {
            //Clear TransactionData Session
            _httpContextAccessor.HttpContext.Session.Remove("TransactionDataModel");

            try
            {
                model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
            }
            catch (Exception ex)
            {
                model = new TransactionDataModel();
                model.EventFlag = ActionTran;
                model.modelCategories = new ViewCategories();
                model.TransactionDetail = new TransactionDetail();
                model.modelCategories.Id_ProcCost = 0;
                model.modelCategories.Id_kProd = 0;
                model.modelCategories.Id_ProdType = 0;
                model.modelCategories.Id_MatType = 10;
                model.modelCategories.Id_PU = 1;
                model.modelCategories.Id_SU = 1;

                model.Username = _username;
                model.SaleORG = _saleOrg;
                model.PlantCode = _plantCode;
            }
            return model;
        }

        public TransactionDataModel BindDataToModelCategoriesBackward(TransactionDataModel model)
        {
            model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
            return model;
        }

        public TransactionDataModel SaveDataToModel_Categories(TransactionDataModel temp)
        {
            var model = new TransactionDataModel();
            model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
            model.modelCategories.ID = 1;
            model.modelCategories.Id_kProdGrp = temp.modelCategories.Id_kProdGrp;
            model.modelCategories.KpgName = temp.modelCategories.KpgName;
            model.modelCategories.Id_ProcCost = temp.modelCategories.Id_ProcCost;
            model.modelCategories.Id_kProd = temp.modelCategories.Id_kProd;
            model.modelCategories.Id_ProdType = temp.modelCategories.Id_ProdType;
            //model.modelCategories.ProductTypeName = CategoriesRepository.GetPDTName(_pMTsDbContext, temp.modelCategories.Id_ProdType);
            model.modelCategories.Id_MatType = temp.modelCategories.Id_MatType;
            model.modelCategories.MatCode = model.modelCategories.MaterialTypeList.FirstOrDefault(m => m.Id == temp.modelCategories.Id_MatType).MatCode;
            model.modelCategories.Id_PU = temp.modelCategories.Id_PU;
            model.modelCategories.Id_SU = temp.modelCategories.Id_SU;
            model.modelCategories.HierarchyLV2 = temp.modelCategories.HierarchyLV2;

            return model;
        }

        //get and match categories
        public TransactionDataModel GetCategoriesData()
        {
            var model = new TransactionDataModel();
            ViewCategories viewCategories = new ViewCategories();

            try
            {
                //data.modelCategories.KindOfProductList
                viewCategories.KindOfProductList = JsonConvert.DeserializeObject<List<KindOfProduct>>(Convert.ToString(_kindOfProductAPIRepository.GetKindOfProductList(_saleOrg,_plantCode)));
                viewCategories.KindOfProductGroupList = JsonConvert.DeserializeObject<List<KindOfProductGroup>>(Convert.ToString(_kindOfProductGroupAPIRepository.GetKindOfProductGroupList(_saleOrg, _plantCode)));
                viewCategories.ProcessCostList = JsonConvert.DeserializeObject<List<ProcessCost>>(Convert.ToString(_processCostAPIRepository.GetProcessCostList(_saleOrg, _plantCode)));
                viewCategories.ProductTypeList = JsonConvert.DeserializeObject<List<ProductType>>(Convert.ToString(_productTypeAPIRepository.GetProductTypeList(_saleOrg, _plantCode)));
                viewCategories.MaterialTypeList = JsonConvert.DeserializeObject<List<MaterialType>>(Convert.ToString(_materialTypeAPIRepository.GetMaterialTypeList(_saleOrg, _plantCode)));
                viewCategories.UnitMaterialList = JsonConvert.DeserializeObject<List<UnitMaterial>>(Convert.ToString(_unitMaterialAPIRepository.GetUnitMaterialList(_saleOrg, _plantCode)));
                viewCategories.HierarchyLV2List = JsonConvert.DeserializeObject<List<HierarchyLv2Matrix>>(Convert.ToString(_hierarchyLv2APIRepository.GetHierarchyLv2List(_saleOrg, _plantCode)));

                _httpContextAccessor.HttpContext.Session.Remove("TransactionDataModel");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            model = new TransactionDataModel();
            model.EventFlag = "Create";
            model.modelCategories = new ViewCategories();
            model.TransactionDetail = new TransactionDetail();
            model.modelCategories = viewCategories;
            model.modelCategories.Id_ProcCost = 0;
            model.modelCategories.Id_kProd = 0;
            model.modelCategories.Id_ProdType = 0;
            model.modelCategories.Id_MatType = 10;
            model.modelCategories.Id_PU = 1;
            model.modelCategories.Id_SU = 1;

            return model;
        }
    }
}
