﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class ProductPropService : IProductPropService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly UserSessionModel userSessionModel;
        PMTsDbContext _pMTsDbContext;
        public ProductPropService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;

            userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
        }

        public TransactionDataModel ProductPropData(TransactionDataModel model)
        {
            // model = new TransactionDataModel();

            if (model.modelProductProp == null)
            {
                model.modelProductProp = new ProductPropViewModel();
                //Get Joint
                model.modelProductProp.JoinList = ProductPropRepository.GetListJoint(_pMTsDbContext).Select(s => new SelectListItem() { Value = s.JointName.ToString(), Text = s.JointName.ToString() });

                // GetPrintMethod
                model.modelProductProp.PrintMethodList = ProductPropRepository.GetListPrintMethod(_pMTsDbContext).Select(s => new SelectListItem() { Value = s.Method.ToString(), Text = s.Method.ToString() });


                //GetPallet
                model.modelProductProp.PalletSize = "1.00x1.20";
                model.modelProductProp.PalletList = ProductPropRepository.GetPalletSize(_pMTsDbContext).Select(s => new SelectListItem()
                { Value = s.PalletWidth.ToString() + "x" + s.PalletLength.ToString(), Text = s.PalletWidth.ToString() + "x" + s.PalletLength.ToString() });

                // model.modelProductSpec.Hig = 255;
                // var Hig = model.modelProductSpec.Hig;
                // model.modelProductProp.PiecePatch = 50;
                model.modelProductProp.Wire = (model.modelProductSpec.Hig / 50) + 1;
                model.modelProductProp.CutSheetWid = model.modelProductSpec.CutSheetWid;
                model.modelProductProp.CutSheetLeng = model.modelProductSpec.CutSheetLeng;

                string MaterialNo = model.MaterialNo;
                // string MaterialNo = "Z03D300003";
                string MatString = MaterialNo.Substring(MaterialNo.Length - 5);

                //string output = temp.Substring(temp.Length - 1, 5);
                //Ean(0) = "885" & Format(Factory, "0000") & Right(Trim(lblMaterial.Text), 5)

                string[] Ean = new string[14];
                Ean[0] = "885" + userSessionModel.SaleOrg + MatString;
                //    Ean[0] = "885" + "0258" + MatString;

                Ean[1] = Ean[0].Substring(0, 1);
                Ean[2] = Ean[0].Substring(1, 1);
                Ean[3] = Ean[0].Substring(2, 1);
                Ean[4] = Ean[0].Substring(3, 1);
                Ean[5] = Ean[0].Substring(4, 1);
                Ean[6] = Ean[0].Substring(5, 1);
                Ean[7] = Ean[0].Substring(6, 1);
                Ean[8] = Ean[0].Substring(7, 1);
                Ean[9] = Ean[0].Substring(8, 1);
                Ean[10] = Ean[0].Substring(9, 1);
                Ean[11] = Ean[0].Substring(10, 1);
                Ean[12] = Ean[0].Substring(11, 1);
                // Ean[12] = "";

                int[] EanLevel = new int[5];
                EanLevel[0] = 0;
                EanLevel[1] = 0;
                EanLevel[2] = 0;

                for (int i = 1; i < 13; i++)
                {
                    if ((i % 2) == 0)
                    {
                        // EanLevel[1] = EanLevel[1] + Int32.Parse(Ean[i]);
                        EanLevel[1] = EanLevel[1] + Convert.ToInt32(Ean[i]);
                    }
                    else
                    {
                        EanLevel[0] = EanLevel[0] + Convert.ToInt32(Ean[i]);
                    }
                }

                EanLevel[2] = EanLevel[1] * 3;
                EanLevel[3] = EanLevel[0] + EanLevel[2];
                EanLevel[4] = EanLevel[3] % 10;
                if (EanLevel[4] == 0)
                {
                    Ean[13] = "0";
                }
                else
                {
                    Ean[13] = (10 - EanLevel[4]).ToString();

                }


                var EANCODE = Ean[0] + Ean[13];
                model.modelProductProp.EANCODE = EANCODE;



            }


            model.modelProductProp.JoinList = ProductPropRepository.GetListJoint(_pMTsDbContext).Select(s => new SelectListItem() { Value = s.JointName.ToString(), Text = s.JointName.ToString() });

            // GetPrintMethod
            model.modelProductProp.PrintMethodList = ProductPropRepository.GetListPrintMethod(_pMTsDbContext).Select(s => new SelectListItem() { Value = s.Method.ToString(), Text = s.Method.ToString() });

            //GetPallet
            //  model.modelProductProp.PalletSize = "1.00x1.20";
            model.modelProductProp.PalletList = ProductPropRepository.GetPalletSize(_pMTsDbContext).Select(s => new SelectListItem()
            { Value = s.PalletWidth.ToString() + "x" + s.PalletLength.ToString(), Text = s.PalletWidth.ToString() + "x" + s.PalletLength.ToString() });

            //GetJoint

            model.modelProductPropChangeHis = new ProductPropChangeHisViewModel();


            //Change History
            var Materialno = model.MaterialNo;
            model.modelProductPropChangeHis.ModelChangeList = ProductPropRepository.GetChangeList(_pMTsDbContext, Materialno);


            return model;
        }

        public TransactionDataModel ProductProp(TransactionDataModel Propdata)
        {
            TransactionDataModel model = new TransactionDataModel();

            try
            {

                model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
                model.modelProductProp = new ProductPropViewModel();
                model.modelProductProp = Propdata.modelProductProp;

                model.modelProductPropChangeHis = new ProductPropChangeHisViewModel();


                //Change History
                var Materialno = model.MaterialNo;
                model.modelProductPropChangeHis.ModelChangeList = ProductPropRepository.GetChangeList(_pMTsDbContext, Materialno);


            }
            catch (Exception ex)
            {
                model.modelProductProp = new ProductPropViewModel();
                model.modelProductPropChangeHis = new ProductPropChangeHisViewModel();

            }
            return model;
        }

        public TransactionDataModel SavePropData(TransactionDataModel temp)
        {
            //   TransactionDataModel model = new TransactionDataModel();
            //  model.modelProductProp = new ProductPropViewModel();
            //   TransactionDataModel model = new TransactionDataModel();
            //    model = SessionExtentions.GetSession<TransactionDataModel>(HttpContext.Session, "TransactionDataModel");

            TblProductProp ProductP = new TblProductProp
            {
                //  MaterialNo = ProductProp.MaterialNo,
                MaterialNo = temp.MaterialNo,
                CutSheetWid = temp.modelProductSpec.CutSheetWid,
                CutSheetLeng = temp.modelProductSpec.CutSheetLeng,
                JoinType = temp.modelProductProp.JoinType,
                Wire = temp.modelProductProp.Wire,
                OuterJoin = temp.modelProductProp.OuterJoin,
                PalletSize = temp.modelProductProp.PalletSize,
                Bun = Convert.ToByte(temp.modelProductProp.Bun),
                BunLayer = Convert.ToByte(temp.modelProductProp.BunLayer),
                LayerPalet = Convert.ToInt16(temp.modelProductProp.LayerPallet),
                BoxPalet = Convert.ToInt16(temp.modelProductProp.BoxPalet),
                //   PicPallet = temp.modelProductProp.PicPallet,
                // PicPallet = temp.modelProductProp.MyImage,
                PieceSet = Convert.ToInt16(temp.modelProductProp.PieceSet),
                PiecePatch = temp.modelProductProp.PiecePatch,
                BoxHandle = temp.modelProductProp.BoxHandle,
                SparePercen = Convert.ToInt16(temp.modelProductProp.SparePercen),
                SpareMax = Convert.ToInt16(temp.modelProductProp.SpareMax),
                SpareMin = Convert.ToInt16(temp.modelProductProp.SpareMin),
                LeadTime = Convert.ToByte(temp.modelProductProp.LeadTime),
                Hardship = temp.modelProductProp.Hardship,
                RunSpeed = temp.modelProductProp.RunSpeed,
                SetupTime = temp.modelProductProp.SetupTime,
                PrepareTime = temp.modelProductProp.PrepareTime,
                PostTime = temp.modelProductProp.PostTime,
                SetupWaste = temp.modelProductProp.SetupWaste,
                RunWaste = temp.modelProductProp.RunWaste,
                SheetStack = temp.modelProductProp.SheetStack,
                RotationIn = temp.modelProductProp.RotationIn,
                Rotationout = temp.modelProductProp.Rotationout,
                ScoreType = temp.modelProductProp.ScoreType,
                ScoreGap = temp.modelProductProp.ScoreGap,
                ChangeInfo = temp.modelProductProp.ChangeInfo,
                // ChangeHistory = temp.modelProductProp.ChangeHistory,
                CreatedDate = DateTime.Now,
                CreatedBy = userSessionModel.UserName,
                Status = true,
                EanCode = temp.modelProductProp.EANCODE,
                PrintMethod = temp.modelProductProp.PrintMethod

            };

            ProductPropRepository.SaveProductProp(_pMTsDbContext, ProductP);
            ProductPropRepository.SaveMasterData(_pMTsDbContext, ProductP, temp.MaterialNo, new SessionsModel {PlantCode = userSessionModel.PlantCode, SaleOrg = userSessionModel.SaleOrg, UserName = userSessionModel.UserName });

            TblChangeHistory PropHistory = new TblChangeHistory
            {
                MaterialNo = temp.MaterialNo,
                ChangeHistory = temp.modelProductProp.ChangeInfo,
                CREATEDDATE = DateTime.Now,
                CREATEDBY = userSessionModel.UserName,
                UPDATEDDATE = DateTime.Now,
                UPDATEDBY = userSessionModel.UserName,
                STATUS = true

            };
            if (temp.modelProductProp.ChangeInfo != null)
            {
                ProductPropRepository.SaveProductChangeHis(_pMTsDbContext, PropHistory);
            }

            // model = new TransactionDataModel();
            //model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");
            //model.modelProductProp = new ProductPropViewModel();
            //   model.modelProductProp = Propdata.modelProductProp;
            // model.modelProductProp = new ProductPropViewModel();
            return temp;
        }

        public TransactionDataModel UpdateChangeHisData(TransactionDataModel temp)
        {
            TblChangeHistory PropHistory = new TblChangeHistory
            {
                MaterialNo = temp.MaterialNo,
                ChangeHistory = temp.modelProductProp.ChangeInfo,
                CREATEDDATE = DateTime.Now,
                CREATEDBY = userSessionModel.UserName,
                UPDATEDDATE = DateTime.Now,
                UPDATEDBY = userSessionModel.UserName,
                STATUS = true

            };
            if (temp.modelProductProp.ChangeInfo != null)
            {
                ProductPropRepository.SaveProductChangeHis(_pMTsDbContext, PropHistory);
            }

            TransactionDataModel model = new TransactionDataModel();
            model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
            model.modelProductProp = new ProductPropViewModel();
            //   model.modelProductProp = Propdata.modelProductProp;
            // model.modelProductProp = new ProductPropViewModel();
            return model;
        }

    }
}
