﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using PMTs.DataAccess;
using PMTs.DataAccess.ModelPresale;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.DataAccess.Repository.Interfaces;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class ProductInfoService : IProductInfoService
    {

        IHttpContextAccessor _httpContextAccessor;

        private readonly IHvaMixAPIRepository _hvaMixAPIRepository;

        private readonly string _username;
        private readonly string _saleOrg;
        private readonly string _plantCode;

        public ProductInfoService(IHttpContextAccessor httpContextAccessor, IHvaMixAPIRepository hvaMixAPIRepository)
        {
            _httpContextAccessor = httpContextAccessor;

            _hvaMixAPIRepository = hvaMixAPIRepository;

            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
            _username = userSessionModel.UserName;
            _saleOrg = userSessionModel.SaleOrg;
            _plantCode = userSessionModel.PlantCode;
        }

        public TransactionDataModel ProductInfoGetData(PMTsDbContext context, HttpContext sessionContext)
        {
            TransactionDataModel model = new TransactionDataModel();
            model.modelProductInfo = new ProductInfoView();

            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(sessionContext.Session, "userSessionModel");
            string saleOrg = userSessionModel.SaleOrg;
            string plantCode = userSessionModel.PlantCode;

            List<DataAccess.ModelsNew.HvaMix> HvaList1 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 1));
            List<DataAccess.ModelsNew.HvaMix> HvaList2 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 2));
            List<DataAccess.ModelsNew.HvaMix> HvaList3 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 3));
            List<DataAccess.ModelsNew.HvaMix> HvaList4 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 4));
            List<DataAccess.ModelsNew.HvaMix> HvaList5 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 5));
            List<DataAccess.ModelsNew.HvaMix> HvaList6 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 6));
            List<DataAccess.ModelsNew.HvaMix> HvaList7 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 7));

            model.modelProductInfo.HVL_ProdTypeList1 = HvaList1.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
            model.modelProductInfo.HVL_ProdTypeList2 = HvaList2.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
            model.modelProductInfo.HVL_ProdTypeList3 = HvaList3.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
            model.modelProductInfo.HVL_ProdTypeList4 = HvaList4.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
            model.modelProductInfo.HVL_ProdTypeList5 = HvaList5.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
            model.modelProductInfo.HVL_ProdTypeList6 = HvaList6.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
            model.modelProductInfo.HVL_ProdTypeList7 = HvaList7.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });

            return model;
        }

        public TransactionDataModel ProductInfoData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel ProdInfo)
        {
            TransactionDataModel model = new TransactionDataModel();

            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(sessionContext.Session, "userSessionModel");
            string saleOrg = userSessionModel.SaleOrg;
            string plantCode = userSessionModel.PlantCode;

            try
            {

                model = SessionExtentions.GetSession<TransactionDataModel>(sessionContext.Session, "TransactionDataModel");

                if (model.modelProductInfo == null && ProdInfo.modelProductInfo == null)
                {
                    model.modelProductInfo = new ProductInfoView();

                    List<DataAccess.ModelsNew.HvaMix> HvaList1 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 1));
                    List<DataAccess.ModelsNew.HvaMix> HvaList2 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 2));
                    List<DataAccess.ModelsNew.HvaMix> HvaList3 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 3));
                    List<DataAccess.ModelsNew.HvaMix> HvaList4 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 4));
                    List<DataAccess.ModelsNew.HvaMix> HvaList5 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 5));
                    List<DataAccess.ModelsNew.HvaMix> HvaList6 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 6));
                    List<DataAccess.ModelsNew.HvaMix> HvaList7 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 7));

                    model.modelProductInfo.HVL_ProdTypeList1 = HvaList1.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList2 = HvaList2.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList3 = HvaList3.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList4 = HvaList4.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList5 = HvaList5.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList6 = HvaList6.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList7 = HvaList7.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });

                }
                else if (ProdInfo.modelProductInfo != null)
                {
                    model.modelProductInfo = ProdInfo.modelProductInfo;

                    List<DataAccess.ModelsNew.HvaMix> HvaList1 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 1));
                    List<DataAccess.ModelsNew.HvaMix> HvaList2 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 2));
                    List<DataAccess.ModelsNew.HvaMix> HvaList3 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 3));
                    List<DataAccess.ModelsNew.HvaMix> HvaList4 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 4));
                    List<DataAccess.ModelsNew.HvaMix> HvaList5 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 5));
                    List<DataAccess.ModelsNew.HvaMix> HvaList6 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 6));
                    List<DataAccess.ModelsNew.HvaMix> HvaList7 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 7));

                    model.modelProductInfo.HVL_ProdTypeList1 = HvaList1.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList2 = HvaList2.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList3 = HvaList3.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList4 = HvaList4.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList5 = HvaList5.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList6 = HvaList6.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList7 = HvaList7.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });

                }
                else if(model.modelProductInfo!=null)
                {
                    List<DataAccess.ModelsNew.HvaMix> HvaList1 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 1));
                    List<DataAccess.ModelsNew.HvaMix> HvaList2 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 2));
                    List<DataAccess.ModelsNew.HvaMix> HvaList3 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 3));
                    List<DataAccess.ModelsNew.HvaMix> HvaList4 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 4));
                    List<DataAccess.ModelsNew.HvaMix> HvaList5 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 5));
                    List<DataAccess.ModelsNew.HvaMix> HvaList6 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 6));
                    List<DataAccess.ModelsNew.HvaMix> HvaList7 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 7));

                    model.modelProductInfo.HVL_ProdTypeList1 = HvaList1.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList2 = HvaList2.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList3 = HvaList3.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList4 = HvaList4.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList5 = HvaList5.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList6 = HvaList6.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                    model.modelProductInfo.HVL_ProdTypeList7 = HvaList7.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                }

                if (model.modelProductInfo.Description == null)
                {
                    model.modelProductInfo.Description = model.modelProductCustomer.CustCode + " ";
                }
            }
            catch (Exception ex)
            {
                model.modelProductInfo = new ProductInfoView();

                List<DataAccess.ModelsNew.HvaMix> HvaList1 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 1));
                List<DataAccess.ModelsNew.HvaMix> HvaList2 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 2));
                List<DataAccess.ModelsNew.HvaMix> HvaList3 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 3));
                List<DataAccess.ModelsNew.HvaMix> HvaList4 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 4));
                List<DataAccess.ModelsNew.HvaMix> HvaList5 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 5));
                List<DataAccess.ModelsNew.HvaMix> HvaList6 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 6));
                List<DataAccess.ModelsNew.HvaMix> HvaList7 = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.HvaMix>>(_hvaMixAPIRepository.GetHvaByGroup(saleOrg, plantCode, 7));

                model.modelProductInfo.HVL_ProdTypeList1 = HvaList1.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                model.modelProductInfo.HVL_ProdTypeList2 = HvaList2.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                model.modelProductInfo.HVL_ProdTypeList3 = HvaList3.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                model.modelProductInfo.HVL_ProdTypeList4 = HvaList4.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                model.modelProductInfo.HVL_ProdTypeList5 = HvaList5.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                model.modelProductInfo.HVL_ProdTypeList6 = HvaList6.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });
                model.modelProductInfo.HVL_ProdTypeList7 = HvaList7.Select(s => new SelectListItem() { Value = s.HvaCode.ToString(), Text = s.HvaDescription });

            }

            if(model.TransactionDetail == null)
            {
                model.TransactionDetail = new TransactionDetail();
            }

            model.TransactionDetail.ProductTypDetail = model.modelCategories.ProductTypeName;
            model.TransactionDetail.HierarchyLV2Detail = model.modelCategories.HierarchyLV2;
            model.TransactionDetail.CustNameDetail = model.modelProductCustomer.CustName;
            model.TransactionDetail.PCDetail = model.modelProductInfo.PC;

            if (model.TransactionDetail.RoutingDetail == null)
            {
                model.TransactionDetail.RoutingDetail = new List<RoutingDataModel>();
            }

            return model;

        }

        public void SaveMasterData(PMTsDbContext context, HttpContext sessionContext, PresaleContext presaleContext, TransactionDataModel model, string MatNo)
        {

            try
            {
                // High Value
                string hvacode;
                string High_Value, High_Group;
                High_Value = ""; High_Group = "";

                hvacode = model.modelProductInfo.hvacode;

                if (hvacode != null)
                {
                    var HvaCodeList = HVARepository.GetHVAMIXMASTER(context, hvacode);

                    High_Value = HvaCodeList.hva_code;
                    High_Group = HvaCodeList.hva_group;

                }

                SessionsModel sessions = new SessionsModel
                {
                    UserName = sessionContext.Session.GetString("username"),
                    SaleOrg = sessionContext.Session.GetString("SALE_ORG"),
                    PlantCode = sessionContext.Session.GetString("PLANT_CODE"),
                };

                string SaleUomtemp = CategoriesRepository.GetSaleUom(context, model.modelCategories.Id_SU);
                string proType = CategoriesRepository.GetproType(context, model.modelCategories.Id_kProd);

                MasterData prod = new MasterData
                {
                    MaterialNo = MatNo,
                    SaleOrg = sessions.SaleOrg,
                    Plant = sessions.PlantCode,
                    PartNo = model.modelProductInfo.PartNo,
                    Pc = model.modelProductInfo.PC,
                    Hierarchy = "",
                    CustCode = model.modelProductCustomer.CustCode,
                    CusId = model.modelProductCustomer.CustId,
                    CustName = model.modelProductCustomer.CustName,
                    Description = model.modelProductInfo.Description,
                    SaleText1 = model.modelProductInfo.SaleText1,
                    SaleText2 = model.modelProductInfo.SaleText2,
                    SaleText3 = model.modelProductInfo.SaleText3,
                    SaleText4 = model.modelProductInfo.SaleText4,
                    //Change = product.Change,
                    Language = "TH",
                    //product.Sale_Text4,
                    //IndGrp = product.IndGrp,
                    //IndDes = product.IndDes,
                    MaterialType = model.modelCategories.MatCode,
                    //PrintMethod = product.PrintMethod,
                    TwoPiece = false,
                    //Flute = product.Flute,
                    PdisStatus = "N",
                    TranStatus = false,
                    SapStatus = false,
                    //JoinType = product.JoinType,
                    CreateDate = DateTime.Now,
                    CreatedBy = sessions.UserName,
                    LastUpdate = DateTime.Now,
                    UpdatedBy = sessions.UserName,
                    HighValue = High_Value,
                    HighGroup = High_Group,
                    SaleUom = SaleUomtemp,
                    ProType = proType,
                    BoxType = model.modelCategories.ProductTypeName,
                    PsmId = model.PsmId
                    };

                MasterdataRepository.CreateMasterdata(context, prod);

                if (model.EventFlag == "Presale")
                {
                    PresaleRepository.updateMatPresale(presaleContext, prod);
                    
                }
                                     
                TblTransactionsDetail TransactionsDetail = new TblTransactionsDetail
                {
                    MaterialNo = MatNo,
                    IDkpg = model.modelCategories.Id_kProdGrp,
                    IDpcc = model.modelCategories.Id_ProcCost ,
                    IDkop = model.modelCategories.Id_kProd,
                    IDpdt = model.modelCategories.Id_ProdType,
                    IDmtt = model.modelCategories.Id_MatType,
                    IDpu = model.modelCategories.Id_PU,
                    IDsu = model.modelCategories.Id_SU,
                    CustReq = model.modelProductCustomer.CustReq,
                    MaterialComment = model.modelProductCustomer.MaterialComment
                };

                ProductInfoRepository.CreateTransactionsDetail(context, TransactionsDetail);
            }
            catch (Exception ex)
            {
               
            }

        }

        public string GenMatNo(PMTsDbContext context, string MatType, SessionsModel Sessions)
        {
            RunningType Type = MasterdataRepository.GetRunningType( context,  MatType,  Sessions);

            string Group_ID = Type.GroupId;

            RunningNo Running = MasterdataRepository.GetRunningNo(context, Sessions, Group_ID);

            try
            {
                if (Running == null)
                {
                    var ex = new ArgumentNullException($"Running No does not exist.");
                    throw ex;
                }
                if (Running.Running >= Running.EndNo)
                {
                    var ex = new ArgumentOutOfRangeException(nameof(Running), $"Limited Running No. ,Please contact admin to correct.");
                    throw ex;
                }

                int mat_no;
                string mat_str, Material_No;

                mat_no = Running.Running + 1;
                mat_str = Convert.ToString(mat_no);
                mat_str = mat_str.PadLeft(Running.Length, '0');
                Material_No = Running.Fix + mat_str;

                return Material_No;
            }
            catch (Exception)
            {
                return "";
            }
        }

        public bool DescriptionChack(PMTsDbContext context,string Description,  SessionsModel Sessions)
        {
            MasterData GetMasterData = MasterdataRepository.GetMasterByDescription(context, Description, Sessions);

            if (GetMasterData == null)
            {
                return true; // Not Duplicate
            }
            else
            {
                return false; // Duplicate
            }
        }

        public bool ProdCodeChack(PMTsDbContext context, string ProdCode, SessionsModel Sessions)
        {
            MasterData GetMasterData = MasterdataRepository.GetMasterByProdCode(context, ProdCode, Sessions);

            if (GetMasterData == null)
            {
                return true; // Not Duplicate
            }
            else
            {
                return false; // Duplicate
            }
        }

    }
}
