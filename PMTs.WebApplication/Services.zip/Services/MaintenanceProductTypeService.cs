﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PMTs.DataAccess.Services
{
    public class MaintenanceProductTypeService
    {

    }
}
