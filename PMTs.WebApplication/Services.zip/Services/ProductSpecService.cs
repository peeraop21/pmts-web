﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelsNew;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.DataAccess.Repository.Interfaces;
using PMTs.DataAccess.Shared;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class ProductSpecService : IProductSpecService
    {

        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly ITransactionsDetailAPIRepository _transactionsDetailAPIRepository;

        private readonly string _username;
        private readonly string _saleOrg;
        private readonly string _plantCode;
        
        public ProductSpecService(IHttpContextAccessor httpContextAccessor, ITransactionsDetailAPIRepository transactionsDetailAPIRepository)
        {
            _httpContextAccessor = httpContextAccessor;

            _transactionsDetailAPIRepository = transactionsDetailAPIRepository;

            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
            _username = userSessionModel.UserName;
            _saleOrg = userSessionModel.SaleOrg;
            _plantCode = userSessionModel.PlantCode;
        }

        public TransactionDataModel BindDataToModel_ProductSpec(TransactionDataModel model)
        {
            if (model.modelProductSpec == null)
            {
                model.modelProductSpec = new ProductSpecViewModel();
                model.modelProductSpec.MaterialNo = model.MaterialNo;

                if (model.modelCategories.Id_ProdType == 130 || model.modelCategories.Id_ProdType == 131)
                    model.modelProductSpec.Slit = 1;
                else
                {
                    //model.modelProductSpec.Slit = ProductSpecRepository.GetSlit(context, sessionContext.Session.GetString("PLANT_CODE"), sessionContext.Session.GetString("SALE_ORG"));
                    model.modelProductSpec.Slit = Convert.ToInt32(JsonConvert.DeserializeObject<PmtsConfig>(Convert.ToString(PMTsConfigAPIRepository.GetSlit(_saleOrg, _plantCode))).FucValue);
                }
                    
                model.modelProductSpec.BoardLists = new List<BoardViewModel>();
                //model.modelProductSpec.BoardLists = ProductSpecRepository.GetBoard(context, model.PlantCode, model.modelCategories.HierarchyLV2);
                if (model.modelCategories.HierarchyLV3 == null)
                    model.modelCategories.HierarchyLV3 = "OOO";

                string costField = JsonConvert.DeserializeObject<DataAccess.ModelsNew.MapCost>(Convert.ToString(MapCostAPIRepository.GetCostField(_saleOrg, _plantCode, model.modelCategories.HierarchyLV2, model.modelCategories.HierarchyLV3))).CostField;
                model.modelProductSpec.BoardLists = JsonConvert.DeserializeObject<List<BoardViewModel>>(Convert.ToString(BoardCombineAPIRepository.GetBoard(_saleOrg, _plantCode, costField, model.modelCategories.HierarchyLV2, model.modelCategories.HierarchyLV3)));
                model.modelProductSpec.ProductTypeName = model.modelCategories.ProductTypeName;
                model.modelProductSpec.CustName = model.modelProductCustomer.CustName;
                model.modelProductSpec.PC = model.modelProductInfo.PC;
                model.modelProductSpec.Id_ProdType = model.modelCategories.Id_ProdType;

                model.modelProductSpec.Id = 1;
                model.modelProductSpec.No_Slot = 1;
                model.modelProductSpec.Code = "";
                model.modelProductSpec.Flute = "";
                model.modelProductSpec.Board = "";
                model.modelProductSpec.Weight = 0;
                model.modelProductSpec.CostPerTon = 0;
                model.modelProductSpec.Hierarchy = "";

                model.modelProductSpec.Priority = 1;

                model.modelProductSpec.Leg = 0;
                model.modelProductSpec.Wid = 0;
                model.modelProductSpec.Hig = 0;

                model.modelProductSpec.ScoreL8 = 0;
                model.modelProductSpec.ScoreL9 = model.modelProductSpec.Slit;
                model.modelProductSpec.ScoreL6 = 0;
                model.modelProductSpec.ScoreL7 = 0;

                model.modelProductSpec.JointLap = 0;
                model.modelProductSpec.ScoreL2 = 0;
                model.modelProductSpec.ScoreL3 = 0;
                model.modelProductSpec.ScoreL4 = 0;
                model.modelProductSpec.ScoreL5 = 0;

                model.modelProductSpec.ScoreW1 = 0;
                model.modelProductSpec.Scorew2 = 0;
                model.modelProductSpec.Scorew3 = 0;
                model.modelProductSpec.Scorew4 = 0;
                model.modelProductSpec.Scorew5 = 0;
                model.modelProductSpec.Scorew6 = 0;
                model.modelProductSpec.Scorew7 = 0;
                model.modelProductSpec.Scorew8 = 0;
                model.modelProductSpec.Scorew9 = 0;
                model.modelProductSpec.Scorew10 = 0;
                model.modelProductSpec.Scorew11 = 0;
                model.modelProductSpec.Scorew12 = 0;
                model.modelProductSpec.Scorew13 = 0;
                model.modelProductSpec.Scorew14 = 0;
                model.modelProductSpec.Scorew15 = 0;
                model.modelProductSpec.Scorew16 = 0;
                model.modelProductSpec.CutSheetWid = 0;
                model.modelProductSpec.CutSheetLeng = 0;

                model.modelProductSpec.SheetArea = 0;
                model.modelProductSpec.BoxArea = 0;
                model.modelProductSpec.WeightSh = 0;
                model.modelProductSpec.WeightBox = 0;
            }
            else
            {
                model.modelProductSpec.MaterialNo = model.MaterialNo;

                if (model.modelCategories.Id_ProdType == 130 || model.modelCategories.Id_ProdType == 131)
                    model.modelProductSpec.Slit = 1;
                else
                {
                    model.modelProductSpec.Slit = Convert.ToInt32(JsonConvert.DeserializeObject<PmtsConfig>(Convert.ToString(PMTsConfigAPIRepository.GetSlit(_saleOrg, _plantCode))).FucValue);
                    //model.modelProductSpec.Slit = ProductSpecRepository.GetSlit(context, sessionContext.Session.GetString("PLANT_CODE"), sessionContext.Session.GetString("SALE_ORG"));
                }
                    
            }

            SessionExtentions.SetSession(_httpContextAccessor.HttpContext.Session, "TransactionDataModel", model);

            return model;
        }

        public TransactionDataModel BindDataToModel_EditProductSpec(TransactionDataModel model)
        {
            if (model.modelProductSpec == null)
            {
                model.modelProductSpec = new ProductSpecViewModel();
                model.modelProductSpec.MaterialNo = model.MaterialNo;

                if (model.modelCategories.Id_ProdType == 130 || model.modelCategories.Id_ProdType == 131)
                    model.modelProductSpec.Slit = 1;
                else
                {
                    //model.modelProductSpec.Slit = ProductSpecRepository.GetSlit(context, sessionContext.Session.GetString("PLANT_CODE"), sessionContext.Session.GetString("SALE_ORG"));
                    model.modelProductSpec.Slit = Convert.ToInt32(JsonConvert.DeserializeObject<PmtsConfig>(Convert.ToString(PMTsConfigAPIRepository.GetSlit(_saleOrg, _plantCode))).FucValue);
                }
                    
                model.modelProductSpec.BoardLists = new List<BoardViewModel>();
                //model.modelProductSpec.BoardLists = ProductSpecRepository.GetBoard(context, model.PlantCode, model.modelCategories.HierarchyLV2);
                string costField = JsonConvert.DeserializeObject<DataAccess.ModelsNew.MapCost>(Convert.ToString(MapCostAPIRepository.GetCostField(_saleOrg, _plantCode, model.modelCategories.HierarchyLV2, model.modelCategories.HierarchyLV3)));
                model.modelProductSpec.BoardLists = JsonConvert.DeserializeObject<List<BoardViewModel>>(Convert.ToString(BoardCombineAPIRepository.GetBoard(_saleOrg, _plantCode, costField, model.modelCategories.HierarchyLV2, model.modelCategories.HierarchyLV3)));

                model.modelProductSpec.ProductTypeName = model.modelCategories.ProductTypeName;
                model.modelProductSpec.CustName = model.modelProductCustomer.CustName;
                model.modelProductSpec.PC = model.modelProductInfo.PC;
                model.modelProductSpec.Id_ProdType = model.modelCategories.Id_ProdType;

                model.modelProductSpec.Id = 1;
                model.modelProductSpec.No_Slot = 1;
                model.modelProductSpec.Code = "";
                model.modelProductSpec.Flute = "";
                model.modelProductSpec.Board = "";
                model.modelProductSpec.Weight = 0;
                model.modelProductSpec.CostPerTon = 0;
                model.modelProductSpec.Hierarchy = "";

                model.modelProductSpec.Priority = 1;

                model.modelProductSpec.Leg = 0;
                model.modelProductSpec.Wid = 0;
                model.modelProductSpec.Hig = 0;

                model.modelProductSpec.ScoreL8 = 0;
                model.modelProductSpec.ScoreL9 = 0;
                model.modelProductSpec.ScoreL6 = 0;
                model.modelProductSpec.ScoreL7 = 0;

                model.modelProductSpec.JointLap = 0;
                model.modelProductSpec.ScoreL2 = 0;
                model.modelProductSpec.ScoreL3 = 0;
                model.modelProductSpec.ScoreL4 = 0;
                model.modelProductSpec.ScoreL5 = 0;

                model.modelProductSpec.ScoreW1 = 0;
                model.modelProductSpec.Scorew2 = 0;
                model.modelProductSpec.Scorew3 = 0;
                model.modelProductSpec.CutSheetWid = 0;
                model.modelProductSpec.CutSheetLeng = 0;

                model.modelProductSpec.SheetArea = 0;
                model.modelProductSpec.BoxArea = 0;
                model.modelProductSpec.WeightSh = 0;
                model.modelProductSpec.WeightBox = 0;
            }
            else
            {
                model.modelProductSpec.MaterialNo = model.MaterialNo;

                if (model.modelCategories.Id_ProdType == 130 || model.modelCategories.Id_ProdType == 131)
                    model.modelProductSpec.Slit = 1;
                else
                {
                    model.modelProductSpec.Slit = Convert.ToInt32(JsonConvert.DeserializeObject<PmtsConfig>(Convert.ToString(PMTsConfigAPIRepository.GetSlit(_saleOrg, _plantCode))).FucValue);
                    //model.modelProductSpec.Slit = ProductSpecRepository.GetSlit(context, sessionContext.Session.GetString("PLANT_CODE"), sessionContext.Session.GetString("SALE_ORG"));
                }                   
            }

            SessionExtentions.SetSession(_httpContextAccessor.HttpContext.Session, "TransactionDataModel", model);

            return model;
        }

        public int chkPriority(ProductSpecViewModel model)
        {
            TransactionDataModel modelx = new TransactionDataModel();
            modelx = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
            var dup = 0;
            var bName = GetBoardName(model);
            if (bName == model.Board)
            {
                dup = 100;
            }
            else
            {
                model.MaterialNo = modelx.modelProductSpec.MaterialNo;

                var List = modelx.modelProductSpec.BoardAlt.Where(b => (b.MaterialNo == model.MaterialNo && b.Priority == model.Priority) || (b.MaterialNo == model.MaterialNo && b.BoardName == bName)).ToList();

                if (List.Count == 0)
                    dup = modelx.modelProductSpec.BoardAlt.Count + 2;
                else
                    dup = 99;
            }
            return dup;
        }

        public string GetBoardName(ProductSpecViewModel board)
        {
            var bName = "";
            if (board.GL != "" && board.GL != null && board.GL != "undefined")
                bName = board.GL;
            else
                board.GL = "";
            //////////////////////////////////////////////
            if (board.BM != "" && board.BM != null && board.BM != "undefined")
                bName = bName + "/" + board.BM;
            else
                board.BM = "";
            //////////////////////////////////////////////
            if (board.BL != "" && board.BL != null && board.BL != "undefined")
                bName = bName + "/" + board.BL;
            else
                board.BL = "";
            //////////////////////////////////////////////
            if (board.CM != "" && board.CM != null && board.CM != "undefined")
                bName = bName + "/" + board.CM;
            else
                board.CM = "";
            //////////////////////////////////////////////
            if (board.CL != "" && board.CL != null && board.CL != "undefined")
                bName = bName + "/" + board.CL;
            else
                board.CL = "";
            //////////////////////////////////////////////
            if (board.DM != "" && board.DM != null && board.DM != "undefined")
                bName = bName + "/" + board.DM;
            else
                board.DM = "";
            //////////////////////////////////////////////
            if (board.DL != "" && board.DL != null && board.DL != "undefined")
                bName = bName + "/" + board.DL;
            else
                board.DL = "";

            return bName;
        }

        public string GetBoardKIWI(string boardCombine)
        {
            var bKiwi = "";
            var flu = "";
            
            string[] ArrarBoard = boardCombine.Split("/");

            List<PaperGrade> pp = JsonConvert.DeserializeObject<PmtsConfig>(Convert.ToString(PaperGradeAPIRepository.GetPaperGradeList(_saleOrg, _plantCode)));

            if (ArrarBoard.Count() > 0)
            {
                if (ArrarBoard[0].Length == 1)
                    flu = ArrarBoard[0] + " ";
                else
                    flu = ArrarBoard[0];
            }

            bKiwi = flu;

            if (ArrarBoard.Count() > 1)
            {
                //var board1 = ProductSpecRepository.GetKIWI(context, ArrarBoard[1].Trim());
                var board1 = pp.Where(p => p.Grade == ArrarBoard[1].Trim());
                bKiwi = bKiwi + "/" + board1;
            }
            if (ArrarBoard.Count() > 2)
            {
                //var board2 = ProductSpecRepository.GetKIWI(context, ArrarBoard[2].Trim());
                var board2 = pp.Where(p => p.Grade == ArrarBoard[2].Trim());
                bKiwi = bKiwi + "/" + board2;
            }
            if (ArrarBoard.Count() > 3)
            {
                //var board3 = ProductSpecRepository.GetKIWI(context, ArrarBoard[3].Trim());
                var board3 = pp.Where(p => p.Grade == ArrarBoard[3].Trim());
                bKiwi = bKiwi + "/" + board3;
            }
            if (ArrarBoard.Count() > 4)
            {
                //var board4 = ProductSpecRepository.GetKIWI(context, ArrarBoard[4].Trim());
                var board4 = pp.Where(p => p.Grade == ArrarBoard[4].Trim());
                bKiwi = bKiwi + "/" + board4;
            }
            if (ArrarBoard.Count() > 5)
            {
                //var board5 = ProductSpecRepository.GetKIWI(context, ArrarBoard[5].Trim());
                var board5 = pp.Where(p => p.Grade == ArrarBoard[5].Trim());
                bKiwi = bKiwi + "/" + board5;
            }
            if (ArrarBoard.Count() > 6)
            {
                //var board6 = ProductSpecRepository.GetKIWI(context, ArrarBoard[6].Trim());
                var board6 = pp.Where(p => p.Grade == ArrarBoard[6].Trim());
                bKiwi = bKiwi + "/" + board6;
            }
            if (ArrarBoard.Count() > 7)
            {
                //var board7 = ProductSpecRepository.GetKIWI(context, ArrarBoard[7].Trim());
                var board7 = pp.Where(p => p.Grade == ArrarBoard[7].Trim());
                bKiwi = bKiwi + "/" + board7;
            }

            return bKiwi;
        }

        public ProductSpecViewModel AddBoardAlt(ProductSpecViewModel model)
        {
            TransactionDataModel modelx;
            modelx = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
            model.MaterialNo = modelx.MaterialNo;
            model.BoardName = GetBoardName(model);

            if (modelx.modelProductSpec.BoardAlt == null)
                modelx.modelProductSpec.BoardAlt = new List<BoardAltViewModel>();

            var flu = "";
            if (model.Flute.Length == 1)
                flu = model.Flute + " /";
            else
                flu = model.Flute + "/";

            modelx.modelProductSpec.BoardAlt.Add(new BoardAltViewModel
            {
                MaterialNo = model.MaterialNo,
                BoardName = model.BoardName,
                BoardKiwi = GetBoardKIWI(flu + model.BoardName),
                Priority = model.Priority,
                Active = model.Active,
                Flute = model.Flute,
                GL = model.GL,
                BM = model.BM,
                BL = model.BL,
                CM = model.CM,
                CL = model.CL,
                DM = model.DM,
                DL = model.DL
            });
            modelx.modelProductSpec.chkPrior = modelx.modelProductSpec.BoardAlt.Count + 1;
            SessionExtentions.SetSession(_httpContextAccessor.HttpContext.Session, "TransactionDataModel", modelx);

            return modelx.modelProductSpec;
        }

        public ProductSpecViewModel RemoveBoardAlt(int prior)
        {
            TransactionDataModel modelx;
            modelx = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");

            int seqNumber = 1;
            //modelx.modelProductSpec.BoardAlt = ProductSpecRepository.RemoveBoardAlt(context, sessions, prior, modelx.MaterialNo);
            modelx.modelProductSpec.BoardAlt.RemoveAt(prior - 1);
            modelx.modelProductSpec.BoardAlt.ForEach(i => { i.Priority = seqNumber; seqNumber++; });
            modelx.modelProductSpec.chkPrior = modelx.modelProductSpec.BoardAlt.Count + 1;

            SessionExtentions.SetSession(_httpContextAccessor.HttpContext.Session, "TransactionDataModel", modelx);

            return modelx.modelProductSpec;
        }

        public ProductSpecViewModel ShowBoardAlt()
        {
            TransactionDataModel modelx;
            modelx = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");

            if (modelx.modelProductSpec.BoardAlt == null)
                modelx.modelProductSpec.BoardAlt = new List<BoardAltViewModel>();

            modelx.modelProductSpec.chkPrior = modelx.modelProductSpec.BoardAlt.Count + 1;

            SessionExtentions.SetSession(_httpContextAccessor.HttpContext.Session, "TransactionDataModel", modelx);

            return modelx.modelProductSpec;
        }

        public TransactionDataModel SaveDataToModel_ProductSpec(TransactionDataModel temp, string[] fileName)
        {
            TransactionDataModel model;

            model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
            if (model.modelCategories.Id_ProdType == 130 || model.modelCategories.Id_ProdType == 131)
                model.modelProductSpec.No_Slot = temp.modelProductSpec.No_Slot == null ? 0 : temp.modelProductSpec.No_Slot;
            else
                model.modelProductSpec.No_Slot = 0;
            model.modelProductSpec.Code = temp.modelProductSpec.Code;
            model.modelProductSpec.Flute = temp.modelProductSpec.Flute;
            model.modelProductSpec.Board = temp.modelProductSpec.Board;
            //model.modelProductSpec.BoardName = GetBoardName(temp);
            model.modelProductSpec.BoardKIWI = temp.modelProductSpec.BoardKIWI;
            model.modelProductSpec.Weight = temp.modelProductSpec.Weight;
            model.modelProductSpec.CostPerTon = temp.modelProductSpec.CostPerTon;
            model.modelProductSpec.Hierarchy = temp.modelProductSpec.Hierarchy;

            //var flute = ProductSpecRepository.GetFlute(context, model.PlantCode, model.modelProductSpec.Flute);
            var flute = JsonConvert.DeserializeObject<Flute>(Convert.ToString(FluteAPIRepository.GetFluteByFlute(_saleOrg, _plantCode, model.modelProductSpec.Flute)));
            model.modelProductSpec.A = flute.A;
            model.modelProductSpec.B = flute.B;
            model.modelProductSpec.C = flute.C;
            model.modelProductSpec.D1 = flute.D1;
            model.modelProductSpec.D2 = flute.D2;
            model.modelProductSpec.JoinSize = flute.JoinSize;

            model.modelProductSpec.Leg = temp.modelProductSpec.Leg;
            model.modelProductSpec.Wid = temp.modelProductSpec.Wid;
            model.modelProductSpec.Hig = temp.modelProductSpec.Hig;

            model.modelProductSpec.ScoreL8 = temp.modelProductSpec.ScoreL8 == null ? 0 : temp.modelProductSpec.ScoreL8;
            model.modelProductSpec.ScoreL9 = temp.modelProductSpec.ScoreL9 == null ? 0 : temp.modelProductSpec.ScoreL9;
            model.modelProductSpec.ScoreL6 = temp.modelProductSpec.ScoreL6 == null ? 0 : temp.modelProductSpec.ScoreL6;
            model.modelProductSpec.ScoreL7 = temp.modelProductSpec.ScoreL7 == null ? 0 : temp.modelProductSpec.ScoreL7;

            model.modelProductSpec.JointLap = temp.modelProductSpec.JointLap;
            model.modelProductSpec.ScoreL2 = temp.modelProductSpec.ScoreL2 == null ? 0 : temp.modelProductSpec.ScoreL2;
            model.modelProductSpec.ScoreL3 = temp.modelProductSpec.ScoreL3 == null ? 0 : temp.modelProductSpec.ScoreL3;
            model.modelProductSpec.ScoreL4 = temp.modelProductSpec.ScoreL4 == null ? 0 : temp.modelProductSpec.ScoreL4;
            model.modelProductSpec.ScoreL5 = temp.modelProductSpec.ScoreL5 == null ? 0 : temp.modelProductSpec.ScoreL5;
            model.modelProductSpec.Slit = temp.modelProductSpec.Slit == null ? 0 : temp.modelProductSpec.Slit;

            model.modelProductSpec.ScoreW1 = temp.modelProductSpec.ScoreW1 == null ? 0 : temp.modelProductSpec.ScoreW1;
            model.modelProductSpec.Scorew2 = temp.modelProductSpec.Scorew2 == null ? 0 : temp.modelProductSpec.Scorew2;
            model.modelProductSpec.Scorew3 = temp.modelProductSpec.Scorew3 == null ? 0 : temp.modelProductSpec.Scorew3;
            model.modelProductSpec.Scorew4 = temp.modelProductSpec.Scorew4 == null ? 0 : temp.modelProductSpec.Scorew4;
            model.modelProductSpec.Scorew5 = temp.modelProductSpec.Scorew5 == null ? 0 : temp.modelProductSpec.Scorew5;
            model.modelProductSpec.Scorew6 = temp.modelProductSpec.Scorew6 == null ? 0 : temp.modelProductSpec.Scorew6;
            model.modelProductSpec.Scorew7 = temp.modelProductSpec.Scorew7 == null ? 0 : temp.modelProductSpec.Scorew7;
            model.modelProductSpec.Scorew8 = temp.modelProductSpec.Scorew8 == null ? 0 : temp.modelProductSpec.Scorew8;
            model.modelProductSpec.Scorew9 = temp.modelProductSpec.Scorew9 == null ? 0 : temp.modelProductSpec.Scorew9;
            model.modelProductSpec.Scorew10 = temp.modelProductSpec.Scorew10 == null ? 0 : temp.modelProductSpec.Scorew10;
            model.modelProductSpec.Scorew11 = temp.modelProductSpec.Scorew11 == null ? 0 : temp.modelProductSpec.Scorew11;
            model.modelProductSpec.Scorew12 = temp.modelProductSpec.Scorew12 == null ? 0 : temp.modelProductSpec.Scorew12;
            model.modelProductSpec.Scorew13 = temp.modelProductSpec.Scorew13 == null ? 0 : temp.modelProductSpec.Scorew13;
            model.modelProductSpec.Scorew14 = temp.modelProductSpec.Scorew14 == null ? 0 : temp.modelProductSpec.Scorew14;
            model.modelProductSpec.Scorew15 = temp.modelProductSpec.Scorew15 == null ? 0 : temp.modelProductSpec.Scorew15;
            model.modelProductSpec.Scorew16 = temp.modelProductSpec.Scorew16 == null ? 0 : temp.modelProductSpec.Scorew16;
            model.modelProductSpec.CutSheetWid = temp.modelProductSpec.CutSheetWid;
            model.modelProductSpec.CutSheetLeng = temp.modelProductSpec.CutSheetLeng;
            model.modelProductSpec.TwoPiece = temp.modelProductSpec.TwoPiece;
            model.modelProductSpec.GLWid = temp.modelProductSpec.GLWid;

            var WeightAndArea = new List<ProductSpecViewModel>();

            if (model.modelCategories.Id_ProdType == 90 || model.modelCategories.Id_ProdType == 100 || model.modelCategories.Id_ProdType == 110)
            {
                model.modelProductSpec.BoxArea = temp.modelProductSpec.BoxArea;
                WeightAndArea = ComputeDC(model.modelProductSpec);
            }
            else
                WeightAndArea = ComputeWeightAndArea(model.modelProductSpec);

            model.modelProductSpec.SheetArea = WeightAndArea.First().SheetArea;
            model.modelProductSpec.BoxArea = WeightAndArea.First().BoxArea;
            model.modelProductSpec.WeightSh = WeightAndArea.First().WeightSh;
            model.modelProductSpec.WeightBox = WeightAndArea.First().WeightBox;

            model.modelProductSpec.PrintMasterPath = fileName[1];
            model.modelProductSpec.UnUpgradBoard = temp.modelProductSpec.UnUpgradBoard;
            model.modelProductSpec.DimensionPropertiesImageBase64String = temp.modelProductSpec.DimensionPropertiesImageBase64String;

            var PrintMasterBase64 = _httpContextAccessor.HttpContext.Session.GetString("PrintMaster");

            if (PrintMasterBase64 != null)
            {
                model.modelProductSpec.PrintMaster = PrintMasterBase64;
            }

            model.modelProductSpec.MaterialNo = model.MaterialNo;
            //ProductSpecRepository.SaveProductSpec(context, sessions, model.modelProductSpec, fileName[0]);
            SaveProductSpec(model.modelProductSpec, fileName[0]);
            //ProductSpecRepository.UpdateTblTransactionsDetail(context, model.modelProductSpec);
            UpdateTransactionsDetail(model.modelProductSpec);

            model.TransactionDetail.BoardDetail = model.modelProductSpec.Board;
            model.TransactionDetail.CostDetail = Convert.ToString(model.modelProductSpec.CostPerTon);

            SessionExtentions.SetSession(_httpContextAccessor.HttpContext.Session, "TransactionDataModel", model);

            //var BoardUse = context.BoardUse.Where(x => x.MaterialNo == model.MaterialNo).ToList();
            //if (BoardUse.Count == 0)
            //    ProductSpecRepository.CreateBoardUse(context, sessions, model.modelProductSpec);
            //else
            //    ProductSpecRepository.UpdateBoardUse(context, sessions, model.modelProductSpec);
            SaveBoardUse(model.modelProductSpec);

            //ProductSpecRepository.UpdateCostIntoPlantView(context, sessions, model);
            UpdateCostIntoPlantView(model);
            if (model.modelProductSpec.BoardAlt != null)
            {
                //ProductSpecRepository.RemoveBoardAlt(context, sessions, model.MaterialNo);
                //ProductSpecRepository.AddBoardAlt(context, sessions, model.modelProductSpec);
                RemoveBoardAlt(model.MaterialNo);
                AddBoardAlt(model.modelProductSpec);
            }

            return model;
        }

        public void SaveProductSpec(ProductSpecViewModel board, string picpath)
        {
            ParentModel Parent = new ParentModel();
            Parent.AppName = Globals.AppNameEncrypt;
            Parent.SaleOrg = _saleOrg;
            Parent.PlantCode = _plantCode;

            List<DataAccess.ModelsNew.PaperGrade> ppg;

            var st = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.BoardSpec>>(Convert.ToString(BoardSpecAPIRepository.GetBoardSpecByBoardId(_saleOrg, _plantCode, board.Code)));
            ppg = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.PaperGrade>>(Convert.ToString(PaperGradeAPIRepository.GetPaperGradeList(_saleOrg, _plantCode)));

            Parent.MasterData.MaterialNo = board.MaterialNo;
            Parent.MasterData.Plant = _plantCode;
            Parent.MasterData.Hierarchy = board.Hierarchy;
            Parent.MasterData.TwoPiece = board.TwoPiece;
            Parent.MasterData.Flute = board.Flute;
            Parent.MasterData.Code = board.Code;
            Parent.MasterData.Board = board.Board;
            if (st.Count > 0)
            {
                Parent.MasterData.Gl = ppg.Where(p => p.Grade == st[0].PaperDes).FirstOrDefault().Paper;
                Parent.MasterData.Glweigth = Convert.ToInt32(ppg.Where(p => p.Grade == st[0].PaperDes).FirstOrDefault().BasicWeight);
            }
            if (st.Count > 1) {
                Parent.MasterData.Bm = ppg.Where(p => p.Grade == st[1].PaperDes).FirstOrDefault().Paper;
                Parent.MasterData.Bmweigth = Convert.ToInt32(ppg.Where(p => p.Grade == st[1].PaperDes).FirstOrDefault().BasicWeight);
            }
            if (st.Count > 2) {
                Parent.MasterData.Bl = ppg.Where(p => p.Grade == st[2].PaperDes).FirstOrDefault().Paper;
                Parent.MasterData.Blweigth = Convert.ToInt32(ppg.Where(p => p.Grade == st[2].PaperDes).FirstOrDefault().BasicWeight);
            }
            if (st.Count > 3) {
                Parent.MasterData.Cm = ppg.Where(p => p.Grade == st[3].PaperDes).FirstOrDefault().Paper;
                Parent.MasterData.Cmweigth = Convert.ToInt32(ppg.Where(p => p.Grade == st[3].PaperDes).FirstOrDefault().BasicWeight);
            }
            if (st.Count > 4) {
                Parent.MasterData.Cl = ppg.Where(p => p.Grade == st[4].PaperDes).FirstOrDefault().Paper;
                Parent.MasterData.Clweigth = Convert.ToInt32(ppg.Where(p => p.Grade == st[4].PaperDes).FirstOrDefault().BasicWeight);
            }
            if (st.Count > 5) {
                Parent.MasterData.Dm = ppg.Where(p => p.Grade == st[5].PaperDes).FirstOrDefault().Paper;
                Parent.MasterData.Dmweigth = Convert.ToInt32(ppg.Where(p => p.Grade == st[5].PaperDes).FirstOrDefault().BasicWeight);
            }
            if (st.Count > 6) {
                Parent.MasterData.Dl = ppg.Where(p => p.Grade == st[6].PaperDes).FirstOrDefault().Paper;
                Parent.MasterData.Dlweigth = Convert.ToInt32(ppg.Where(p => p.Grade == st[6].PaperDes).FirstOrDefault().BasicWeight);
            }
            
            Parent.MasterData.Wid = board.Wid;
            Parent.MasterData.Leg = board.Leg;
            Parent.MasterData.Hig = board.Hig;
            Parent.MasterData.CutSheetLeng = board.CutSheetLeng;
            Parent.MasterData.CutSheetWid = board.CutSheetWid;
            Parent.MasterData.SheetArea = board.SheetArea;
            Parent.MasterData.BoxArea = board.BoxArea;
            Parent.MasterData.ScoreW1 = Convert.ToInt16(board.ScoreW1);
            Parent.MasterData.Scorew2 = Convert.ToInt16(board.Scorew2);
            Parent.MasterData.Scorew3 = Convert.ToInt16(board.Scorew3);
            Parent.MasterData.Scorew4 = Convert.ToInt16(board.Scorew4);
            Parent.MasterData.Scorew5 = Convert.ToInt16(board.Scorew5);
            Parent.MasterData.Scorew6 = Convert.ToInt16(board.Scorew6);
            Parent.MasterData.Scorew7 = Convert.ToInt16(board.Scorew7);
            Parent.MasterData.Scorew8 = Convert.ToInt16(board.Scorew8);
            Parent.MasterData.Scorew9 = Convert.ToInt16(board.Scorew9);
            Parent.MasterData.Scorew10 = Convert.ToInt16(board.Scorew10);
            Parent.MasterData.Scorew11 = Convert.ToInt16(board.Scorew11);
            Parent.MasterData.Scorew12 = Convert.ToInt16(board.Scorew12);
            Parent.MasterData.Scorew13 = Convert.ToInt16(board.Scorew13);
            Parent.MasterData.Scorew14 = Convert.ToInt16(board.Scorew14);
            Parent.MasterData.Scorew15 = Convert.ToInt16(board.Scorew15);
            Parent.MasterData.Scorew16 = Convert.ToInt16(board.Scorew16);
            Parent.MasterData.JointLap = Convert.ToByte(board.JointLap);
            Parent.MasterData.ScoreL2 = Convert.ToInt16(board.ScoreL2);
            Parent.MasterData.ScoreL3 = Convert.ToInt16(board.ScoreL3);
            Parent.MasterData.ScoreL4 = Convert.ToInt16(board.ScoreL4);
            Parent.MasterData.ScoreL5 = Convert.ToInt16(board.ScoreL5);
            Parent.MasterData.ScoreL6 = Convert.ToInt16(board.ScoreL6);
            Parent.MasterData.ScoreL7 = Convert.ToInt16(board.ScoreL7);
            Parent.MasterData.ScoreL8 = Convert.ToInt16(board.ScoreL8);
            Parent.MasterData.ScoreL9 = Convert.ToInt16(board.ScoreL9);
            Parent.MasterData.Slit = Convert.ToByte(board.Slit);
            Parent.MasterData.NoSlot = Convert.ToInt16(board.No_Slot);
            Parent.MasterData.WeightSh = board.WeightSh;
            Parent.MasterData.WeightBox = board.WeightBox;
            Parent.MasterData.DiecutPictPath = picpath;
            Parent.MasterData.UnUpgradBoard = board.UnUpgradBoard;
            Parent.MasterData.LastUpdate = DateTime.Now;
            Parent.MasterData.UpdatedBy = _username;

            string MasterDataJsonString = JsonConvert.SerializeObject(Parent);

            MasterDataAPIRepository.UpdateMasterData(MasterDataJsonString);
        }

        public void SaveBoardUse(ProductSpecViewModel board)
        {
            ParentModel Parent = new ParentModel();
            Parent.AppName = Globals.AppNameEncrypt;
            Parent.SaleOrg = _saleOrg;
            Parent.PlantCode = _plantCode;
            Parent.BoardUse.MaterialNo = board.MaterialNo;
            Parent.BoardUse.BoardId = board.Code;
            Parent.BoardUse.BoardName = board.Board;
            Parent.BoardUse.Kiwi = board.BoardKIWI;
            Parent.BoardUse.Priority = 1;
            Parent.BoardUse.Active = true;
            Parent.BoardUse.Flute = board.Flute;
            //var st = GetBoardSpec(context, plantCode, board.Code);
            var st = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.BoardSpec>>(Convert.ToString(BoardSpecAPIRepository.GetBoardSpecByBoardId(_saleOrg, _plantCode, board.Code)));
            if (st.Count > 0)
                Parent.BoardUse.Gl = st[0].PaperDes;
            if (st.Count > 1)
                Parent.BoardUse.Bm = st[1].PaperDes;
            if (st.Count > 2)
                Parent.BoardUse.Bl = st[2].PaperDes;
            if (st.Count > 3)
                Parent.BoardUse.Cm = st[3].PaperDes;
            if (st.Count > 4)
                Parent.BoardUse.Cl = st[4].PaperDes;
            if (st.Count > 5)
                Parent.BoardUse.Dm = st[5].PaperDes;
            if (st.Count > 6)
                Parent.BoardUse.Dl = st[6].PaperDes;
            Parent.BoardUse.Weight = Convert.ToDouble(board.Weight);
            Parent.BoardUse.CreatedBy = _username;
            Parent.BoardUse.CreatedDate = DateTime.Now;

            string BoardUseJsonString = JsonConvert.SerializeObject(Parent);
            
            try
            {
                BoardUseAPIRepository.SaveBoardUse(BoardUseJsonString);
            }
            catch
            {
                BoardUseAPIRepository.UpdateBoardUse(BoardUseJsonString);
            }
        }

        public void UpdateCostIntoPlantView(TransactionDataModel model)
        {
            ParentModel Parent = new ParentModel();
            Parent.AppName = Globals.AppNameEncrypt;
            Parent.SaleOrg = _saleOrg;
            Parent.PlantCode = _plantCode;
            Parent.PlantView = JsonConvert.DeserializeObject<DataAccess.ModelsNew.PlantView>(Convert.ToString(PlantViewAPIRepository.GetPlantViewByMat(_saleOrg, _plantCode, model.MaterialNo)));

            if (model.modelCategories.MatCode == "82")
            {
                Parent.PlantView.StdTotalCost = 0;
                Parent.PlantView.StdMovingCost = Convert.ToDouble(model.modelProductSpec.CostPerTon);
            }
            else
            {
                Parent.PlantView.StdTotalCost = Convert.ToDouble(model.modelProductSpec.CostPerTon);
                Parent.PlantView.StdMovingCost = 0;
            }
            string PlantViewJsonString = JsonConvert.SerializeObject(Parent);

            PlantViewAPIRepository.SavePlantView(PlantViewJsonString);
        }

        public void UpdateTransactionsDetail(ProductSpecViewModel model)
        {
            ParentModel Parent = new ParentModel();
            Parent.AppName = Globals.AppNameEncrypt;
            Parent.SaleOrg = _saleOrg;
            Parent.PlantCode = _plantCode;
            Parent.TransactionsDetail = JsonConvert.DeserializeObject<DataAccess.ModelsNew.TransactionsDetail>(Convert.ToString(_transactionsDetailAPIRepository.GetTransactionsDetailByMat(_saleOrg, _plantCode, model.MaterialNo)));
            Parent.TransactionsDetail.Glwid = model.GLWid; 
            string TransactionsDetailJsonString = JsonConvert.SerializeObject(Parent);

            _transactionsDetailAPIRepository.UpdateTransactionsDetail(TransactionsDetailJsonString);
        }

        public void RemoveBoardAlt(string mat)
        {
            var del = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.BoardAlternative>>(Convert.ToString(BoardAlternativeAPIRepository.GetBoardAlternativeByMat(_saleOrg, _plantCode, mat)));

            foreach (var item in del)
            {
                ParentModel Parent = new ParentModel();
                Parent.AppName = Globals.AppNameEncrypt;
                Parent.SaleOrg = _saleOrg;
                Parent.PlantCode = _plantCode;
                
                dynamic itemSpecToDelete = BoardAltSpecAPIRepository.GetBoardAltSpecById(_saleOrg, _plantCode, item.id);

                Parent.BoardAltSpecList = JsonConvert.DeserializeObject<List<BoardAltSpec>>(Convert.ToString(itemSpecToDelete));
                string BoardAltSpecJsonString = JsonConvert.SerializeObject(Parent);
                BoardAltSpecAPIRepository.DeleteBoardAltSpec(BoardAltSpecJsonString);

                ParentModel Parent1 = new ParentModel();
                Parent1.AppName = Globals.AppNameEncrypt;
                Parent1.SaleOrg = _saleOrg;
                Parent1.PlantCode = _plantCode;

                dynamic itemBoardAltToDelete = BoardAlternativeAPIRepository.GetBoardAlternativeById(_saleOrg, _plantCode, item.id);

                Parent.BoardAlternative = JsonConvert.DeserializeObject<DataAccess.ModelsNew.BoardAlternative>(Convert.ToString(itemBoardAltToDelete));
                string BoardAlternativeJsonString = JsonConvert.SerializeObject(Parent1);
                BoardAlternativeAPIRepository.DeleteBoardAlternative(BoardAlternativeJsonString);
            } 
        }

        public void AddBoardAltToDatabase(ProductSpecViewModel board)
        {
            List<DataAccess.ModelsNew.BoardAlternative> boardAlternativesList = new List<DataAccess.ModelsNew.BoardAlternative>();

            board.BoardAlt.ForEach(i =>
            {
                boardAlternativesList.Add(new DataAccess.ModelsNew.BoardAlternative
                {
                    MaterialNo = board.MaterialNo,
                    BoardName = i.BoardName,
                    BoardKiwi = i.BoardKiwi,
                    SaleOrg = _saleOrg,
                    Plant = _plantCode,
                    Priority = i.Priority,
                    Active = i.Active,
                    Flute = i.Flute,
                    CreatedDate = DateTime.Now,
                    CreatedBy = _username
                });
            });

            ParentModel Parent = new ParentModel();
            Parent.AppName = Globals.AppNameEncrypt;
            Parent.SaleOrg = _saleOrg;
            Parent.PlantCode = _plantCode;

            Parent.BoardAlternativeList = boardAlternativesList;

            string BoardAlternativeJsonString = JsonConvert.SerializeObject(Parent);
            BoardAlternativeAPIRepository.SaveBoardAlternative(BoardAlternativeJsonString);
        }

        public List<ProductSpecViewModel> ComputeRSC(ProductSpecViewModel model)
        {
            List<ProductSpecViewModel> modelx = new List<ProductSpecViewModel>();
            int? w = model.Wid;
            int? l = model.Leg;
            int? h = model.Hig;

            //var flute = ProductSpecRepository.GetFlute(context, sessions.PlantCode, model.Flute);
            var flute = JsonConvert.DeserializeObject<Flute>(Convert.ToString(FluteAPIRepository.GetFluteByFlute(_saleOrg, _plantCode, model.Flute)));

            int? a = flute.A;
            int? b = flute.B;
            int? c = flute.C;
            int? d1 = flute.D1;
            int? d2 = flute.D2;
            int? join = flute.JoinSize;
            int? slit = model.Slit;

            int? hbl = 0;
            int? hbr = 0;
            int? hblx = 0;
            int? hbrx = 0;
            int? ll = 0;
            int? wl = 0;
            int? lr = 0;
            int? wr = 0;
            int lid = 0;
            int? h1 = 0;
            int? shWid = 0;
            int? shLen = 0;

            int? sheet = 0;
            int? box = 0;
            int slot = 0;
            double? sheetw = 0;
            double? boxw = 0;
            double basicw = model.Weight;

            if (model.JoinSize != null)
                join = model.JoinSize;
            if (slit == null)
                slit = JsonConvert.DeserializeObject<PmtsConfig>(Convert.ToString(PMTsConfigAPIRepository.GetPMTsConfigList(_saleOrg, _plantCode)));

            if (model.GLWid == true)
                lid = (int)Math.Floor(Convert.ToDecimal(Convert.ToDouble(l / 2) + c));
            else
                lid = (int)Math.Floor(Convert.ToDecimal(Convert.ToDouble(w / 2) + c));

            if (model.TwoPiece == true)
            {
                hbl = l + a + join;
                hbr = w + b + slit;
                hblx = l + a + w + b;
                hbrx = 0;
                ll = l + a;
                wl = w + b;
                lr = 0;
                wr = 0;

                h1 = h + d1;
                shWid = 2 * lid + h1;
                shLen = l + w + a + b + join + slit;
            }
            else
            {
                hbl = w + l + (2 * a) + join;
                hbr = w + l + a + b + slit;
                hblx = w + l + (2 * a);
                hbrx = w + l + a + b;
                ll = l + a;
                wl = w + a;
                lr = l + a;
                wr = w + b;

                h1 = h + d1;
                shWid = 2 * lid + h1;
                shLen = (2 * l) + (2 * w) + (3 * a) + b + join + slit;
            }

            sheet = shWid * shLen;
            slot = Convert.ToInt32((shWid - h1) * (21.5 + join) + (slit * shWid));
            box = sheet - slot;

            sheetw = (basicw * sheet / 1000000000);
            boxw = (basicw * box / 1000000000);

            modelx.Add(new ProductSpecViewModel()
            {
                ScoreW1 = lid,
                Scorew2 = h1,
                Scorew3 = lid,
                JointLap = join,
                ScoreL2 = ll,
                ScoreL3 = wl,
                ScoreL4 = lr,
                ScoreL5 = wr,
                ScoreL6 = hblx,
                ScoreL7 = hbrx,
                ScoreL8 = hbl,
                ScoreL9 = hbr,
                Slit = slit,
                CutSheetLeng = shLen,
                CutSheetWid = shWid,
                SheetArea = sheet,
                BoxArea = box,
                WeightSh = Convert.ToDouble(Math.Round(Convert.ToDecimal(sheetw), 3)),
                WeightBox = Convert.ToDouble(Math.Round(Convert.ToDecimal(boxw), 3))
            });

            return modelx;
        }

        public List<ProductSpecViewModel> ComputeOneP(ProductSpecViewModel model)
        {
            List<ProductSpecViewModel> modelx = new List<ProductSpecViewModel>();
            int? w = model.Wid;
            int? l = model.Leg;
            int? h = model.Hig;

            //var flute = ProductSpecRepository.GetFlute(context, sessions.PlantCode, model.Flute);
            var flute = JsonConvert.DeserializeObject<Flute>(Convert.ToString(FluteAPIRepository.GetFluteByFlute(_saleOrg, _plantCode, model.Flute)));

            int? a = flute.A;
            int? b = flute.B;
            int? c = flute.C;
            int? d1 = flute.D1;
            int? d2 = flute.D2;
            int? join = flute.JoinSize;
            int? slit = model.Slit;

            int? hbl = 0;
            int? hbr = 0;
            int? hblx = 0;
            int? hbrx = 0;
            int? ll = model.ScoreL2;
            int? wl = model.ScoreL3;
            int? lr = 0;
            int? wr = 0;
            int lid = 0;
            int? h1 = 0;
            int? shWid = model.CutSheetWid;
            int? shLen = 0;

            int? sheet = 0;
            int? box = 0;
            int slot = 0;
            double? sheetw = 0;
            double? boxw = 0;
            double basicw = model.Weight;

            if (model.JoinSize != 0)
                join = model.JoinSize;

            //ll = l + a;
            wl = w + a;
            lr = l + a;
            wr = w + b;
            hblx = w + l + (2 * a);
            hbrx = w + l + a + b;
            hbl = w + l + (2 * a) + join;
            hbr = w + l + a + b + slit;

            h1 = h + d1;
            //shWid = 2 * lid + h1;
            shLen = (2 * l) + (2 * w) + (3 * a) + b + join + slit;

            sheet = shWid * shLen;
            slot = Convert.ToInt32((shWid - h1) * (21.5 + join) + (slit * shWid));
            box = sheet - slot;

            sheetw = (basicw * sheet / 1000000000);
            boxw = (basicw * box / 1000000000);

            modelx.Add(new ProductSpecViewModel()
            {
                //ScoreW1 = lid,
                //Scorew2 = h1,
                //Scorew3 = lid,
                //JointLap = join,
                //ScoreL2 = ll,
                ScoreL3 = wl,
                ScoreL4 = lr,
                ScoreL5 = wr,
                ScoreL6 = hblx,
                ScoreL7 = hbrx,
                ScoreL8 = hbl,
                ScoreL9 = hbr,
                CutSheetLeng = shLen,
                //CutSheetWid = shWid,
                SheetArea = sheet,
                BoxArea = box,
                WeightSh = Convert.ToDouble(Math.Round(Convert.ToDecimal(sheetw), 3)),
                WeightBox = Convert.ToDouble(Math.Round(Convert.ToDecimal(boxw), 3))
            });

            return modelx;
        }

        public List<ProductSpecViewModel> ComputeTwoP(ProductSpecViewModel model)
        {
            List<ProductSpecViewModel> modelx = new List<ProductSpecViewModel>();
            int? w = model.Wid;
            int? l = model.Leg;
            int? h = model.Hig;

            //var flute = ProductSpecRepository.GetFlute(context, sessions.PlantCode, model.Flute);
            var flute = JsonConvert.DeserializeObject<Flute>(Convert.ToString(FluteAPIRepository.GetFluteByFlute(_saleOrg, _plantCode, model.Flute)));

            int? a = flute.A;
            int? b = flute.B;
            int? c = flute.C;
            int? d1 = flute.D1;
            int? d2 = flute.D2;
            int? join = flute.JoinSize;
            int? slit = model.Slit;

            int? hbl = 0;
            int? hbr = 0;
            int? hblx = 0;
            int? hbrx = 0;
            int? ll = 0;
            int? wl = 0;
            int? lr = 0;
            int? wr = 0;
            int? lid1 = model.ScoreW1;
            int? lid2 = model.Scorew3;
            int? h1 = model.Scorew2;
            int? shWid = 0;
            int? shLen = 0;

            int? sheet = 0;
            int? box = 0;
            int slot = 0;
            double? sheetw = 0;
            double? boxw = 0;
            double basicw = model.Weight;

            if (model.JoinSize != 0)
                join = model.JoinSize;

            if (lid1 == 0 && h1 == 0 && lid2 == 0)
            {
                lid1 = (int)Math.Floor(Convert.ToDecimal(Convert.ToDouble(w / 2) + c));
                lid2 = lid1;
            }

            if (model.TwoPiece == true)
            {
                hbl = l + a + join;
                hbr = w + b + slit;
                hblx = l + a + w + b;
                hbrx = 0;
                ll = l + a;
                wl = w + b;
                lr = 0;
                wr = 0;

                h1 = h + d1;
                shWid = lid1 + lid2 + h1;
                shLen = l + w + a + b + join + slit;
            }

            sheet = shWid * shLen;
            slot = Convert.ToInt32((shWid - h1) * (21.5 + join) + (slit * shWid));
            box = sheet - slot;

            sheetw = (basicw * sheet / 1000000000);
            boxw = (basicw * box / 1000000000);

            modelx.Add(new ProductSpecViewModel()
            {
                ScoreW1 = lid1,
                Scorew2 = h1,
                Scorew3 = lid2,
                JointLap = join,
                ScoreL2 = ll,
                ScoreL3 = wl,
                ScoreL4 = lr,
                ScoreL5 = wr,
                ScoreL6 = hblx,
                ScoreL7 = hbrx,
                ScoreL8 = hbl,
                ScoreL9 = hbr,
                CutSheetWid = shWid,
                CutSheetLeng = shLen,
                SheetArea = sheet,
                BoxArea = box,
                WeightSh = Convert.ToDouble(Math.Round(Convert.ToDecimal(sheetw), 3)),
                WeightBox = Convert.ToDouble(Math.Round(Convert.ToDecimal(boxw), 3))
            });

            return modelx;
        }

        public List<ProductSpecViewModel> ComputeDC(ProductSpecViewModel model)
        {
            List<ProductSpecViewModel> modelx = new List<ProductSpecViewModel>();
            int? slit = 0;
            int join = 0;

            int? h1 = 0;
            int? shWid = model.CutSheetWid;
            int? shLen = model.CutSheetLeng;

            int? sheet = 0;
            int? box = model.BoxArea;
            int? slot = 0;
            double? sheetw = 0;
            double? boxw = 0;
            double basicw = model.Weight;


            h1 = 0;
            slot = Convert.ToInt32((shWid - h1) * (21.5 + join) + (slit * shWid));
            sheet = shWid * shLen;

            sheetw = (basicw * sheet / 1000000000);
            boxw = (basicw * box / 1000000000);

            modelx.Add(new ProductSpecViewModel()
            {
                SheetArea = sheet,
                BoxArea = box,
                WeightSh = Convert.ToDouble(Math.Round(Convert.ToDecimal(sheetw), 3)),
                WeightBox = Convert.ToDouble(Math.Round(Convert.ToDecimal(boxw), 3))
            });

            return modelx;
        }

        public List<ProductSpecViewModel> ComputeOther(ProductSpecViewModel model)
        {
            List<ProductSpecViewModel> modelx = new List<ProductSpecViewModel>();
            int? slit = 0;
            int? join = 0;

            int? h1 = 0;
            int? shWid = model.CutSheetWid;
            int? shLen = model.CutSheetLeng;

            int? sheet = 0;
            int? box = model.BoxArea;
            int? slot = 0;
            double? sheetw = 0;
            double? boxw = 0;
            double basicw = model.Weight;

            slot = Convert.ToInt32((shWid - h1) * (21.5 + join) + (slit * shWid));
            sheet = shWid * shLen;
            if (box == null || box == 0)
                box = sheet - slot;

            sheetw = (basicw * sheet / 1000000000);
            boxw = (basicw * box / 1000000000);

            modelx.Add(new ProductSpecViewModel()
            {
                SheetArea = sheet,
                BoxArea = box,
                WeightSh = Convert.ToDouble(Math.Round(Convert.ToDecimal(sheetw), 3)),
                WeightBox = Convert.ToDouble(Math.Round(Convert.ToDecimal(boxw), 3))
            });

            return modelx;
        }

        public List<ProductSpecViewModel> ComputeTeeth(ProductSpecViewModel model)
        {
            List<ProductSpecViewModel> modelx = new List<ProductSpecViewModel>();
            int? slit = model.Slit;
            int? n = model.No_Slot;

            int? hbl = 0;
            int? hbr = 0;
            int? h1 = 0;
            int? shWid = model.CutSheetWid;
            int? shLen = model.CutSheetLeng;

            int? sheet = 0;
            int? box = 0;
            int? slot = 0;
            double? sheetw = 0;
            double? boxw = 0;
            double basicw = model.Weight;


            h1 = shWid / 2;
            hbl = (shLen - (n * slit)) / (n + 1);
            hbr = hbl;
            sheet = shWid * shLen;
            //slot = Convert.ToInt32(shWid * 21.5);
            slot = h1 * slit * n;
            box = sheet - slot;

            sheetw = (basicw * sheet / 1000000000);
            boxw = (basicw * box / 1000000000);

            modelx.Add(new ProductSpecViewModel()
            {
                Scorew2 = h1,
                ScoreL8 = hbl,
                ScoreL9 = hbr,
                SheetArea = sheet,
                BoxArea = box,
                WeightSh = Convert.ToDouble(Math.Round(Convert.ToDecimal(sheetw), 3)),
                WeightBox = Convert.ToDouble(Math.Round(Convert.ToDecimal(boxw), 3))
            });

            return modelx;
        }

        public List<ProductSpecViewModel> ComputeWeightAndArea(ProductSpecViewModel model)
        {
            List<ProductSpecViewModel> modelx = new List<ProductSpecViewModel>();
            int? shWid = model.CutSheetWid;
            int? shLen = model.CutSheetLeng;
            int? slit = model.Slit;
            int? join = model.JointLap;
            int? n = model.No_Slot;
            int? h1 = model.Scorew2;
            double basicw = model.Weight;

            int? sheet = 0;
            int? box = 0;
            int? slot = 0;
            double? sheetw = 0;
            double? boxw = 0;

            if (join == null)
            {
                slot = h1 * slit * n;               
            }
            else
            {
                slot = Convert.ToInt32((shWid - h1) * (21.5 + join) + (slit * shWid));
            }

            sheet = shWid * shLen;
            box = sheet - slot;
            sheetw = (basicw * sheet / 1000000000);
            boxw = (basicw * box / 1000000000);

            modelx.Add(new ProductSpecViewModel()
            {
                SheetArea = sheet,
                BoxArea = box,
                WeightSh = Convert.ToDouble(Math.Round(Convert.ToDecimal(sheetw), 3)),
                WeightBox = Convert.ToDouble(Math.Round(Convert.ToDecimal(boxw), 3))
            });

            return modelx;
        }

        public void SetPicData(string[] Base64)
        {
            TransactionDataModel model = new TransactionDataModel();

            try
            {

                model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
                if (model.modelProductSpec == null) model.modelProductSpec = new ProductSpecViewModel();
                model.modelProductSpec.PrintMasterPath = Base64[0];

                SessionExtentions.SetSession(_httpContextAccessor.HttpContext.Session, "TransactionDataModel", model);
            }
            catch (Exception ex)
            {
                model.modelProductPicture = new ProductPictureView();
            }

        }
    }
}
