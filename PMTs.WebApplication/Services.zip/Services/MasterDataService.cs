﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.Repository;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class MasterDataService : IMasterDataService
    {

        IHttpContextAccessor _httpContextAccessor;

        //IMasterDataAPIRepository _masterDataAPIRepository;

        private readonly string _username;
        private readonly string _saleOrg;
        private readonly string _plantCode;

        public MasterDataService(IHttpContextAccessor httpContextAccessor/*, IMasterDataAPIRepository masterDataAPIRepository*/)
        {
            // Initialize HttpContext
            _httpContextAccessor = httpContextAccessor;

            // Initialize Repository
            //_masterDataAPIRepository = masterDataAPIRepository;

            // Initialize SaleOrg and PlantCode from Session
            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
            _username = userSessionModel.UserName;
            _saleOrg = userSessionModel.SaleOrg;
            _plantCode = userSessionModel.PlantCode;
        }

        public List<VMasterDataRoutingModel> GetMasterdata(PMTsDbContext context, HttpContext sessionContext, string TxtSearch,string ddlSearch)
        {
            SessionsModel sessions = new SessionsModel
            {
                UserName = sessionContext.Session.GetString("username"),
                SaleOrg = sessionContext.Session.GetString("SALE_ORG"),
                PlantCode = sessionContext.Session.GetString("PLANT_CODE"),
            };
            var result = MasterdataRepository.GetMasterdata( context,  sessions,  TxtSearch,  ddlSearch);
            return result;
        }
        
        public VMasterDataViewModel GetMasterdataListView(PMTsDbContext context, SessionsModel sessions)
        {
          
            VMasterDataViewModel model = new VMasterDataViewModel();
            model.ModelList = MasterdataRepository.GetMasterdataListView(context,sessions);
            return model;
        }

        public VMasterDataViewModel GetMasterdataListViewSearch(PMTsDbContext context, SessionsModel sessions,string TxtSearch,string ddlSearch)
        {

            VMasterDataViewModel model = new VMasterDataViewModel();
            model.ModelList = MasterdataRepository.GetMasterdataListViewBysearch(context, sessions, TxtSearch, ddlSearch);
            return model;
        }

    }

}
