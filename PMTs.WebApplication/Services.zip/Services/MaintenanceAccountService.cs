﻿using Newtonsoft.Json;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.MaintenanceAccount;
using PMTs.DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public static class MaintenanceAccountService
    {
        public static MaintenanceAccountModel GetAccountById(int Id)
        {
          //  string jsonString = JsonConvert.SerializeObject(id);
          //  dynamic result = AccountAPIRepository.GetAccountById(jsonString);

            //     LoginViewModel User = new LoginViewModel();
            //  User.UserName = result.Item3.UserName;
            MaintenanceAccountModel AccModel = new MaintenanceAccountModel();
            AccModel.AccountData = AccountAPIRepository.GetAccountById(Id);

     

            return AccModel;

        }
    }
}
