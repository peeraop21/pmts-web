﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.MaintenanceCustomer;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.DataAccess.Repository.Interfaces;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class NewProductService : INewProductService
    {

        IHttpContextAccessor _httpContextAccessor;

        private readonly ICustomerAPIRepository _customerAPIRepository;

        private readonly string _username;
        private readonly string _saleOrg;
        private readonly string _plantCode;

        public NewProductService(IHttpContextAccessor httpContextAccessor, ICustomerAPIRepository customerAPIRepository)
        {
            // Initialize HttpContext
            _httpContextAccessor = httpContextAccessor;

            // Initialize Repository
            _customerAPIRepository = customerAPIRepository;

            // Initialize SaleOrg and PlantCode from Session
            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
            _username = userSessionModel.UserName;
            _saleOrg = userSessionModel.SaleOrg;
            _plantCode = userSessionModel.PlantCode;
        }

        public MasterDataTransactionModel GetMasterDataTransaction(PMTsDbContext dbContext, string actionTran, string materialNo)
        {
            MasterDataTransactionModel oMasterData = new MasterDataTransactionModel();
            oMasterData.tranAction = actionTran;
            oMasterData.masterData = MasterdataRepository.GetMasterByMaterialNo(dbContext, materialNo);
            oMasterData.tblTranDetail = CategoriesRepository.GetCategories(dbContext, materialNo);
            oMasterData.plantView = dbContext.PlantView.Where(x => x.MaterialNo == materialNo && x.Plant == oMasterData.masterData.Plant).FirstOrDefault();
            oMasterData.boardAltViews = ProductSpecRepository.ShowBoardAlt(dbContext, materialNo);
            oMasterData.routings = RoutingRepository.GetRoutingDataByMaterialNo(dbContext, materialNo);

            return oMasterData;
        }

        public MasterDataTransactionModel GetMasterDataTransactionPresale(PMTsDbContext dbContext, MasterDataTransactionModel oMasterData)
        {
            TblTransactionsDetail tranDetail = new TblTransactionsDetail();
            String matType = oMasterData.masterData.MaterialType;

            tranDetail.IDkpg = 0;
            tranDetail.IDpcc = 0;
            tranDetail.IDkop = 0;

            tranDetail.IDpdt = CategoriesRepository.GetProductTypeByName(dbContext, oMasterData.masterData.BoxType).Uid;
            tranDetail.IDmtt = CategoriesRepository.GetMaterialTypeByMatCode(dbContext, oMasterData.masterData.MaterialType).Uid;

             
            if (matType == "84" || matType == "14" || matType == "24") // งาน BOM
            {
                tranDetail.IDpu = 3;
                tranDetail.IDsu = 3;
            }
            else
            {
                int unit = CategoriesRepository.GetSaleUnitByName(dbContext, oMasterData.masterData.SaleUom).Uid;
                tranDetail.IDpu = unit;
                tranDetail.IDsu = unit;
            }
          
            oMasterData.tblTranDetail = tranDetail;
            oMasterData.plantView = new PlantView();
            oMasterData.boardAltViews = new List<BoardAltViewModel>();

            return oMasterData;
        }

        public TransactionDataModel BindDataToModelEditCopy(PMTsDbContext dbContext, HttpContext httpContext, IHostingEnvironment hostEnvironment, string actionTran, string MaterialNo, MasterDataTransactionModel masterDataTran)
        {
            // Clear TransactionData Session
            httpContext.Session.Remove("TransactionDataModel");

            TransactionDataModel model = new TransactionDataModel();
            model.modelCategories = new ViewCategories();
            model.modelProductSpec = new ProductSpecViewModel();
            model.modelProductProp = new ProductPropViewModel();
            model.modelProductERP = new ProductERPPlantViewModel();
            model.modelProductERPSale = new ProductERPSaleViewModel();
            model.modelProductCustomer = new ProductCustomer();
            model.modelProductInfo = new ProductInfoView();
            model.modelRouting = new RoutingViewModel();
            model.modelProductPicture = new ProductPictureView();

            MasterDataTransactionModel oMasterData = new MasterDataTransactionModel();

            if (actionTran == "Presale")
            {
                oMasterData = GetMasterDataTransactionPresale(dbContext, masterDataTran) ;
                oMasterData.tranAction = actionTran;
                model.PsmId = masterDataTran.masterData.PsmId;

            }
            else
            {
                oMasterData = GetMasterDataTransaction(dbContext, actionTran, MaterialNo);
            }

            

            model.EventFlag = actionTran;

            model.modelCategories = BindCategoriesData(dbContext, oMasterData);
            model.modelProductSpec = BindProductSpecData(dbContext, httpContext, oMasterData, hostEnvironment);
            model.modelProductCustomer = BindCustomerData(dbContext, oMasterData);
            model.modelProductInfo = BindProductInfoData(dbContext, oMasterData);
            model.modelRouting = BindRoutingData(dbContext, oMasterData, model.modelProductSpec);
            model.modelProductProp = BindProductProp(dbContext, oMasterData);
            //model.modelProductERP =
            //model.modelProductERPSale =
            model.modelProductERPPurchase = BindDataPurchase(dbContext, oMasterData);
            model.modelProductPicture = BindProductPictureData(dbContext, oMasterData, hostEnvironment);

            SessionsModel sessions = new SessionsModel
            {
                UserName = httpContext.Session.GetString("username"),
                SaleOrg = httpContext.Session.GetString("SALE_ORG"),
                PlantCode = httpContext.Session.GetString("PLANT_CODE"),
            };
            model.Username = sessions.UserName;
            model.PlantCode = sessions.PlantCode;
            model.SaleORG = sessions.SaleOrg;

            model.TransactionDetail = BindDataTransactionDetail(model);

            model.MaterialNo = (actionTran == "Copy" || actionTran == "Presale") ? null : MaterialNo;

            SetTransactionStatus(model, "Categories");

            return model;
        }

        #region BindData

        public ProductERPPurchaseViewModel BindDataPurchase(PMTsDbContext dbContext, MasterDataTransactionModel obj)
        {
            ProductERPPurchaseViewModel model = new ProductERPPurchaseViewModel();
            model.PurTxt1 = obj.masterData.PurTxt1;
            model.PurTxt2 = obj.masterData.PurTxt2;
            model.PurTxt3 = obj.masterData.PurTxt3;
            model.PurTxt4 = obj.masterData.PurTxt4;

            //model.modelProductERPPurchase = ProductERPRepository

            return model;
        }

        public ProductERPPurchaseViewModel BindDataPurchaseByMatNo(PMTsDbContext dbContext, string materialNo)
        {
            var master = ProductPropRepository.GetProductProp(dbContext, materialNo);
            ProductERPPurchaseViewModel model = new ProductERPPurchaseViewModel();
            model.PurTxt1 = master.PurTxt1;
            model.PurTxt2 = master.PurTxt2;
            model.PurTxt3 = master.PurTxt3;
            model.PurTxt4 = master.PurTxt4;

            return model;
        }

        public ProductPropViewModel BindProductProp(PMTsDbContext dbContext, MasterDataTransactionModel obj)
        {
            ProductPropViewModel model = new ProductPropViewModel();
            model.MaterialNo = obj.masterData.MaterialNo;
            model.CutSheetWid = obj.masterData.CutSheetWid;
            model.CutSheetLeng = obj.masterData.CutSheetLeng;
            model.JoinType = obj.masterData.JoinType;
            model.Wire = obj.masterData.Wire;
            model.OuterJoin = obj.masterData.OuterJoin == true ? true : false;
            model.EANCODE = obj.masterData.EanCode;
            model.PalletSize = obj.masterData.PalletSize;
            model.Bun = obj.masterData.Bun;
            model.BunLayer = obj.masterData.BunLayer;
            model.LayerPallet = obj.masterData.LayerPalet;
            model.BoxPalet = obj.masterData.BoxPalet;
            model.PieceSet = obj.masterData.PieceSet;
            model.PiecePatch = obj.masterData.PiecePatch;
            model.BoxHandle = obj.masterData.BoxHandle == true ? true : false;
            model.SparePercen = obj.masterData.SparePercen;
            model.SpareMin = obj.masterData.SpareMin;
            model.SpareMax = obj.masterData.SpareMax;
            model.Hardship = obj.masterData.Hardship;
            model.LeadTime = obj.masterData.LeadTime;

            model.RunSpeed = obj.masterData.RunSpeed;
            model.SetupTime = obj.masterData.SetupTime;
            model.PrepareTime = obj.masterData.PrepareTime;
            model.PostTime = obj.masterData.PostTime;
            model.SetupWaste = obj.masterData.SetupWaste;
            model.RunWaste = obj.masterData.RunWaste;
            model.SheetStack = obj.masterData.SheetStack;
            model.RotationIn = obj.masterData.RotationIn;
            model.Rotationout = obj.masterData.Rotationout;
            model.ScoreType = obj.masterData.ScoreType;
            model.ScoreGap = obj.masterData.ScoreGap;
            model.ChangeInfo = obj.masterData.ChangeInfo;
            model.PrintMethod = obj.masterData.PrintMethod;
            //model.ChangeHistory = MasterProp.ChangeHistory;
            //Get Joint
            model.JoinList = ProductPropRepository.GetListJoint(dbContext).Select(s => new SelectListItem() { Value = s.JointName.ToString(), Text = s.JointName.ToString() });
            // GetPrintMethod
            model.PrintMethodList = ProductPropRepository.GetListPrintMethod(dbContext).Select(s => new SelectListItem() { Value = s.Method.ToString(), Text = s.Method.ToString() });


            //GetPallet
            //model.PalletSize = "1.00x1.20";
            model.PalletList = ProductPropRepository.GetPalletSize(dbContext).Select(s => new SelectListItem()
            { Value = s.PalletWidth.ToString() + "x" + s.PalletLength.ToString(), Text = s.PalletWidth.ToString() + "x" + s.PalletLength.ToString() });

            return model;
        }

        public ProductCustomer BindCustomerData(PMTsDbContext dbContext, MasterDataTransactionModel obj)
        {
            ProductCustomer model = new ProductCustomer();
            var Cust = CustomerRepository.GetCustomerDataByCustCode(dbContext, obj.masterData.CustCode, obj.masterData.SaleOrg, obj.masterData.Plant);

            if (Cust != null)
            {
                model.CustCode = Cust.Cust_Code;
                model.CustId = Cust.Cust_ID;
                model.CustName = Cust.Cust_Name;
                model.SoldTo = Cust.Sold_to_Code;
                model.CusAlert = Cust.Cust_Alert;
                model.DeliveryTime = Cust.Cust_DeliveryTime;
                model.Zone = Cust.Zone;
                model.Route = Cust.Route;

                if (Cust.Ship_to != null)
                {
                    var array = Cust.Ship_to.Split(',');
                    string restOfArray = string.Join('\n', array.Skip(1));
                    model.ShipTo = restOfArray;
                }

            }
                
            model.CustReq = obj.tblTranDetail.CustReq;
            model.MaterialComment = obj.tblTranDetail.MaterialComment;

            return model;
        }

        public RoutingViewModel BindRoutingData(PMTsDbContext dbContext, MasterDataTransactionModel obj, ProductSpecViewModel modelProductSpec)
        {
            RoutingViewModel model = new RoutingViewModel();
            model.RoutingDataList = new List<RoutingDataModel>();

            model.WeightSheetDefault = Math.Round(Convert.ToDecimal(modelProductSpec.WeightSh), 2).ToString();

            model.WeightSelectList = new SelectList(new List<SelectListItem> {
                new SelectListItem { Selected = false, Text = Math.Round(Convert.ToDecimal(modelProductSpec.WeightSh), 2).ToString(), Value = Math.Round(Convert.ToDecimal(modelProductSpec.WeightSh), 2).ToString() },
                new SelectListItem { Selected = false, Text = Math.Round(Convert.ToDecimal(modelProductSpec.WeightBox), 2).ToString(), Value = Math.Round(Convert.ToDecimal(modelProductSpec.WeightBox), 2).ToString() },
            }, "Value", "Text", 1);

            model.SheetLengthIn = modelProductSpec.CutSheetLeng.ToString();
            model.SheetLengthOut = modelProductSpec.CutSheetLeng.ToString();
            model.SheetWidthIn = modelProductSpec.CutSheetWid.ToString();
            model.SheetWidthOut = modelProductSpec.CutSheetWid.ToString();

            model.MachineGroupSelectList = RoutingRepository.GetMachineGroupList(dbContext).OrderBy(o => o.MachineGroup).Select(s => s.MachineGroup).Distinct().Select(sli => new SelectListItem { Value = sli, Text = sli });
            model.InkSelectList = RoutingRepository.GetInkShadeList(dbContext).OrderBy(o => o.Ink).Select(s => s.Ink).Distinct().Select(sli => new SelectListItem { Value = sli, Text = sli });
            model.ShadeSelectList = RoutingRepository.GetInkShadeList(dbContext).OrderBy(o => o.Shade).Select(s => s.Shade).Distinct().Select(sli => new SelectListItem { Value = sli, Text = sli });

            obj.routings.ForEach(i =>
            {
                model.RoutingDataList.Add(new RoutingDataModel
                {
                    SeqNo = i.SeqNo,
                    GroupMachine = RoutingRepository.GetMachineGroupByMachine(dbContext, i.Machine),
                    Machine = i.Machine,
                    Alternative1 = i.Alternative1,
                    Alternative2 = i.Alternative2,
                    Alternative3 = i.Alternative3,
                    Alternative4 = i.Alternative4,
                    Alternative5 = i.Alternative5,
                    Alternative6 = i.Alternative6,
                    Alternative7 = i.Alternative7,
                    Alternative8 = i.Alternative8,
                    //StdProcess = 
                    //Speed =
                    //ColourCount =
                    MachineMove = i.McMove.Value,
                    //HandHold =
                    PrintingPlateNo = i.PlateNo,
                    MylaNo = i.MylaNo,
                    PaperRollWidth = i.PaperWidth.ToString(),
                    Cut = i.CutNo.ToString(),
                    Trim = i.Trim.ToString(),
                    PercentTrim = i.PercenTrim.ToString(),
                    //WasteLeg =
                    //WasteWid =
                    SheetLengthIn = i.SheetInLeg.ToString(),
                    SheetWidthIn = i.SheetInWid.ToString(),
                    SheetLengthOut = i.SheetOutLeg.ToString(),
                    SheetWidthOut = i.SheetOutWid.ToString(),
                    WeightIn = i.WeightIn.ToString(),
                    WeightOut = i.WeightOut.ToString(),
                    NoOpenIn = i.NoOpenIn.ToString(),
                    NoOpenOut = i.NoOpenOut.ToString(),
                    Ink1 = i.Color1,
                    Ink2 = i.Color2,
                    Ink3 = i.Color3,
                    Ink4 = i.Color4,
                    Ink5 = i.Color5,
                    Ink6 = i.Color6,
                    Ink7 = i.Color7,
                    Shade1 = i.Shade1,
                    Shade2 = i.Shade2,
                    Shade3 = i.Shade3,
                    Shade4 = i.Shade4,
                    Shade5 = i.Shade5,
                    Shade6 = i.Shade6,
                    Shade7 = i.Shade7,
                    Area1 = i.ColorArea1.ToString(),
                    Area2 = i.ColorArea2.ToString(),
                    Area3 = i.ColorArea3.ToString(),
                    Area4 = i.ColorArea4.ToString(),
                    Area5 = i.ColorArea5.ToString(),
                    Area6 = i.ColorArea6.ToString(),
                    Area7 = i.ColorArea7.ToString(),
                    //Platen = 
                    //Rotary =
                    TearTape = i.TearTape,
                    //NoneBlk =
                    //StanBlk =
                    //SemiBlk
                    //ShipBlk =
                    //BlockNo =
                    JoinToMaterialNo = i.JoinMatNo,
                    SperateToMaterialNo = i.SeparatMatNo,
                    //RemarkInprocess =
                    //Hardship =
                    //PdisStatus =
                    //TranStatus = 
                    //SapStatus = 
                    //RotateIn = 
                    //RotateOut = 
                    //StackHeight =
                    //SetupTm =
                    //SetupWaste =
                    //PrepareTm =
                    //PostTm =
                    //RunWaste =
                    //Human =
                    //ColorCount =
                    //UnUpgradBoard =
                    //ScoreType =
                    //ScoreGap =
                    IsPropCor = dbContext.Machine.Where(w => w.Machine1 == i.Machine).Select(s => s.IsPropCor).Single().Value,
                    IsPropPrint = dbContext.Machine.Where(w => w.Machine1 == i.Machine).Select(s => s.IsPropPrint).Single().Value,
                    IsPropDieCut = dbContext.Machine.Where(w => w.Machine1 == i.Machine).Select(s => s.IsPropDieCut).Single().Value,
                });
            });

            return model;
        }

        public ViewCategories BindCategoriesData(PMTsDbContext dbContext, MasterDataTransactionModel obj)
        {
            ViewCategories model = new ViewCategories();

            model.Id_kProdGrp = obj.tblTranDetail.IDkpg;
            model.Id_ProcCost = obj.tblTranDetail.IDpcc;
            model.Id_kProd = obj.tblTranDetail.IDkop;
            model.Id_ProdType = obj.tblTranDetail.IDpdt;
            model.Id_MatType = obj.tblTranDetail.IDmtt;
            model.Id_PU = obj.tblTranDetail.IDpu;
            model.Id_SU = obj.tblTranDetail.IDsu;

            if (obj.tranAction == "Presale")
            {
                model.PCCList = CategoriesRepository.GenPCCWherePDT(dbContext, model.Id_ProdType).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
                model.KOPList = CategoriesRepository.GenKOPWherePDT(dbContext, model.Id_ProdType).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
                model.PDTList = CategoriesRepository.GenPDTNoWhere(dbContext).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            }
            else
            {
                model.PCCList = CategoriesRepository.GenPCCWhereAll(dbContext, model.Id_kProdGrp, model.Id_kProd, model.Id_ProdType).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
                model.KOPList = CategoriesRepository.GenKOPWhereAll(dbContext, model.Id_kProdGrp, model.Id_ProcCost, model.Id_ProdType).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
                model.PDTList = CategoriesRepository.GenPDTWhereAll(dbContext, model.Id_kProdGrp, model.Id_ProcCost, model.Id_kProd).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            }

            model.MATList = dbContext.TblMaterialType.ToList().Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            model.PUList = dbContext.TblProductUnit.ToList().Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            model.SUList = dbContext.TblSaleUnit.ToList().Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });

            model.KpgName = CategoriesRepository.GetKPGName(dbContext, model.Id_kProdGrp);
            model.MatCode = CategoriesRepository.GetMatCode(dbContext, model.Id_MatType);
            model.ProductTypeName = CategoriesRepository.GetPDTName(dbContext, model.Id_ProdType);
            model.HierarchyLV2 = CategoriesRepository.GenLV2(dbContext, model.Id_ProdType);
            return model;
        }

        public ViewCategories BindCategoriesPresaleData(PMTsDbContext dbContext, string MaterialNo)
        {
            ViewCategories model = new ViewCategories();
            var cat = CategoriesRepository.GetCategories(dbContext, MaterialNo);

            //model.Id_kProdGrp = cat.IDkpg;
            //model.Id_ProcCost = cat.IDpcc;
            //model.Id_kProd = cat.IDkop;
            //model.Id_ProdType = cat.IDpdt;
            //model.Id_MatType = cat.IDmtt;
            //model.Id_PU = cat.IDpu;
            //model.Id_SU = cat.IDsu;

            model.Id_kProdGrp = 0;
            model.Id_ProcCost = 0;
            model.Id_kProd = 0;
            model.Id_ProdType = 70;
            model.Id_MatType = 10;
            model.Id_PU = 1;
            model.Id_SU = 1;

            //model.PCCList = CategoriesRepository.GenPCCWhereAll(dbContext, model.Id_kProdGrp, model.Id_kProd, model.Id_ProdType).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            //model.KOPList = CategoriesRepository.GenKOPWhereAll(dbContext, model.Id_kProdGrp, model.Id_ProcCost, model.Id_ProdType).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            //model.PDTList = CategoriesRepository.GenPDTWhereAll(dbContext, model.Id_kProdGrp, model.Id_ProcCost, model.Id_kProd).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });

            model.PCCList = CategoriesRepository.GenPCCWherePDT(dbContext, model.Id_ProdType).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            model.KOPList = CategoriesRepository.GenKOPWherePDT(dbContext, model.Id_ProdType).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            model.PDTList = CategoriesRepository.GenPDTNoWhere(dbContext).Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });

            model.MATList = dbContext.TblMaterialType.ToList().Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            model.PUList = dbContext.TblProductUnit.ToList().Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });
            model.SUList = dbContext.TblSaleUnit.ToList().Select(s => new SelectListItem() { Value = s.Uid.ToString(), Text = s.Name });

            model.KpgName = CategoriesRepository.GetKPGName(dbContext, model.Id_kProdGrp);
            //model.MatCode = CategoriesRepository.GetMatCode(dbContext, model.Id_MatType);
            model.MatCode = "81";
            model.ProductTypeName = CategoriesRepository.GetPDTName(dbContext, model.Id_ProdType);
            model.HierarchyLV2 = CategoriesRepository.GenLV2(dbContext, model.Id_ProdType);
            return model;
        }


        public ProductSpecViewModel BindProductSpecData(PMTsDbContext dbContext, HttpContext httpContext, MasterDataTransactionModel obj, IHostingEnvironment hostEnvironment)
        {
            ProductSpecViewModel model = new ProductSpecViewModel();
            var Board = ProductSpecRepository.GetBoardByCode(dbContext, obj.masterData.Plant, obj.masterData.Code);
            var LV2 = CategoriesRepository.GenLV2(dbContext, obj.tblTranDetail.IDpdt);

            model.BoardLists = ProductSpecRepository.GetBoard(dbContext, obj.masterData.Plant, LV2);
            model.Code = obj.masterData.Code;
            model.Board = obj.masterData.Board;
            model.Flute = obj.masterData.Flute;
            model.Hierarchy = obj.masterData.Hierarchy;


            if (Board != null)//mook-edit
            {
                if (Board.Kiwi == null)
                    //model.BoardKIWI = ProductSpecService.GetBoardKIWI(dbContext, httpContext, Board.BoardCombine);
                    model.BoardKIWI = string.Empty; // Test
                else
                    model.BoardKIWI = Board.Kiwi;
                model.Weight = Convert.ToDouble(Board.Weight);
            }

            //var plantView = dbContext.PlantView.Where(x => x.MaterialNo == MaterialNo && x.Plant == obj.masterData.Plant).FirstOrDefault(); 

            if (obj.masterData.MaterialType == "82")
            {
                model.CostPerTon = Convert.ToDecimal(obj.plantView.StdMovingCost);
            }
            else
            {
                model.CostPerTon = Convert.ToDecimal(obj.plantView.StdTotalCost);
            }

            //model.BoardAlt = ProductSpecRepository.ShowBoardAlt(dbContext, MaterialNo);
            model.BoardAlt = obj.boardAltViews;
            model.Priority = model.BoardAlt.Count + 1;

            model.Leg = obj.masterData.Leg;
            model.Wid = obj.masterData.Wid;
            model.Hig = obj.masterData.Hig;

            model.GLWid = obj.tblTranDetail.GLwid;
            model.TwoPiece = obj.masterData.TwoPiece;
            model.JointLap = obj.masterData.JointLap == null ? 0 : obj.masterData.JointLap;
            model.ScoreL2 = obj.masterData.ScoreL2 == null ? 0 : obj.masterData.ScoreL2;
            model.ScoreL3 = obj.masterData.ScoreL3 == null ? 0 : obj.masterData.ScoreL3;
            model.ScoreL4 = obj.masterData.ScoreL4 == null ? 0 : obj.masterData.ScoreL4;
            model.ScoreL5 = obj.masterData.ScoreL5 == null ? 0 : obj.masterData.ScoreL5;
            model.Slit = obj.masterData.Slit == null ? 6 : obj.masterData.Slit;
            model.No_Slot = obj.masterData.NoSlot == null ? 0 : obj.masterData.NoSlot;

            model.ScoreL8 = obj.masterData.ScoreL8 == null ? model.ScoreL2 + model.ScoreL3 + model.JointLap : obj.masterData.ScoreL8;
            model.ScoreL9 = obj.masterData.ScoreL9 == null ? model.ScoreL4 + model.ScoreL5 + model.Slit : obj.masterData.ScoreL9;
            model.ScoreL6 = obj.masterData.ScoreL6 == null ? model.ScoreL2 + model.ScoreL3 : obj.masterData.ScoreL6;
            model.ScoreL7 = obj.masterData.ScoreL7 == null ? model.ScoreL4 + model.ScoreL5 : obj.masterData.ScoreL7;

            model.ScoreW1 = obj.masterData.ScoreW1 == null ? 0 : obj.masterData.ScoreW1;
            model.Scorew2 = obj.masterData.Scorew2 == null ? 0 : obj.masterData.Scorew2;
            model.Scorew3 = obj.masterData.Scorew3 == null ? 0 : obj.masterData.Scorew3;
            model.Scorew4 = obj.masterData.Scorew4 == null ? 0 : obj.masterData.Scorew4;
            model.Scorew5 = obj.masterData.Scorew5 == null ? 0 : obj.masterData.Scorew5;
            model.Scorew6 = obj.masterData.Scorew6 == null ? 0 : obj.masterData.Scorew6;
            model.Scorew7 = obj.masterData.Scorew7 == null ? 0 : obj.masterData.Scorew7;
            model.Scorew8 = obj.masterData.Scorew8 == null ? 0 : obj.masterData.Scorew8;
            model.Scorew9 = obj.masterData.Scorew9 == null ? 0 : obj.masterData.Scorew9;
            model.Scorew10 = obj.masterData.Scorew10 == null ? 0 : obj.masterData.Scorew10;
            model.Scorew11 = obj.masterData.Scorew11 == null ? 0 : obj.masterData.Scorew11;
            model.Scorew12 = obj.masterData.Scorew12 == null ? 0 : obj.masterData.Scorew12;
            model.Scorew13 = obj.masterData.Scorew13 == null ? 0 : obj.masterData.Scorew13;
            model.Scorew14 = obj.masterData.Scorew14 == null ? 0 : obj.masterData.Scorew14;
            model.Scorew15 = obj.masterData.Scorew15 == null ? 0 : obj.masterData.Scorew15;
            model.Scorew16 = obj.masterData.Scorew16 == null ? 0 : obj.masterData.Scorew16;
            model.CutSheetWid = obj.masterData.CutSheetWid == null ? model.ScoreW1 + model.Scorew2 + model.Scorew3 : obj.masterData.CutSheetWid;
            model.CutSheetLeng = obj.masterData.CutSheetLeng == null ? model.ScoreW1 + model.Scorew2 + model.Scorew3 : obj.masterData.CutSheetLeng;

            model.SheetArea = obj.masterData.SheetArea == null || obj.masterData.SheetArea == 0 ? model.CutSheetWid * model.CutSheetLeng : obj.masterData.SheetArea;
            int? slot = 0;
            if (model.JointLap == 0)
            {
                slot = model.Scorew2 * model.Slit * model.No_Slot;
            }
            else
            {
                slot = Convert.ToInt32((model.CutSheetWid - model.Scorew2) * (21.5 + model.JointLap) + (model.Slit * model.CutSheetWid));
            }
            model.BoxArea = obj.masterData.BoxArea == null || obj.masterData.BoxArea == 0 ? model.SheetArea - slot : obj.masterData.BoxArea;
            model.WeightSh = obj.masterData.WeightSh == null || obj.masterData.WeightSh == 0 ? Convert.ToDouble(Math.Round(Convert.ToDecimal(model.Weight * model.SheetArea / 1000000000), 4)) : obj.masterData.WeightSh;
            model.WeightBox = obj.masterData.WeightBox == null || obj.masterData.WeightBox == 0 ? Convert.ToDouble(Math.Round(Convert.ToDecimal(model.Weight * model.BoxArea / 1000000000), 4)) : obj.masterData.WeightBox;

            //model.PrintMaster = "";
            model.PrintMasterPath = "";
            model.PrintMaster = obj.masterData.DiecutPictPath;
            model.PrintMasterPath = base64String(hostEnvironment, obj.masterData.DiecutPictPath);


            return model;
        }

        public ProductInfoView BindProductInfoData(PMTsDbContext dbContext, MasterDataTransactionModel obj)
        {
            ProductInfoView result = new ProductInfoView();

            result.PartNo = obj.masterData.PartNo;
            result.Description = obj.masterData.Description;
            result.PC = obj.masterData.Pc;
            result.SaleText1 = obj.masterData.SaleText1;
            result.SaleText2 = obj.masterData.SaleText2;
            result.SaleText3 = obj.masterData.SaleText3;
            result.SaleText4 = obj.masterData.SaleText4;

            List<string> hvaCode = new List<string>(); ;

            if (obj.masterData.HighValue != "" && obj.masterData.HighValue != null)
            {
                var code = HVARepository.GetHVAMIXMASTERbyhvacode(dbContext, obj.masterData.HighValue);
                int count = code.Code.Length / 4;
                string temp;
                int index = 0;
                for (int i = 0; i < count; i++)
                {
                    index = 4 * i;
                    temp = code.Code.Substring(index, 4);
                    hvaCode.Add(temp);
                }
                foreach (var item in hvaCode)
                {
                    var HVAMIX = HVARepository.GetHVAMIXbyHvaCode(dbContext, item);
                    switch (HVAMIX.hva_group)
                    {
                        case 1:
                            result.HvaProductType = HVAMIX.hva_code;
                            break;
                        case 2:
                            result.HvaStructural = HVAMIX.hva_code;

                            break;
                        case 3:
                            result.HvaPrinting = HVAMIX.hva_code;
                            break;
                        case 4:
                            result.HvaFlute = HVAMIX.hva_code;
                            break;
                        case 5:
                            result.HvaCorrugating = HVAMIX.hva_code;
                            break;
                        case 6:
                            result.HvaCoating = HVAMIX.hva_code;
                            break;
                        case 7:
                            result.HvaFinishing = HVAMIX.hva_code;
                            break;

                    }
                    //    model.modelProductInfo = ProdInfo.modelProductInfo;
                    result.HVL_ProdTypeList1 = HVARepository.GetHVAMIXList(dbContext, 1).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                    result.HVL_ProdTypeList2 = HVARepository.GetHVAMIXList(dbContext, 2).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                    result.HVL_ProdTypeList3 = HVARepository.GetHVAMIXList(dbContext, 3).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                    result.HVL_ProdTypeList4 = HVARepository.GetHVAMIXList(dbContext, 4).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                    result.HVL_ProdTypeList5 = HVARepository.GetHVAMIXList(dbContext, 5).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                    result.HVL_ProdTypeList6 = HVARepository.GetHVAMIXList(dbContext, 6).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                    result.HVL_ProdTypeList7 = HVARepository.GetHVAMIXList(dbContext, 7).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });

                }
            }
            else
            {
                result.HVL_ProdTypeList1 = HVARepository.GetHVAMIXList(dbContext, 1).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                result.HVL_ProdTypeList2 = HVARepository.GetHVAMIXList(dbContext, 2).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                result.HVL_ProdTypeList3 = HVARepository.GetHVAMIXList(dbContext, 3).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                result.HVL_ProdTypeList4 = HVARepository.GetHVAMIXList(dbContext, 4).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                result.HVL_ProdTypeList5 = HVARepository.GetHVAMIXList(dbContext, 5).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                result.HVL_ProdTypeList6 = HVARepository.GetHVAMIXList(dbContext, 6).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });
                result.HVL_ProdTypeList7 = HVARepository.GetHVAMIXList(dbContext, 7).Select(s => new SelectListItem() { Value = s.hva_code.ToString(), Text = s.hva_description });

            }

            return result;
        }

        public ProductPictureView BindProductPictureData(PMTsDbContext dbContext, MasterDataTransactionModel obj, IHostingEnvironment hostEnvironment)
        {
            ProductPictureView model = new ProductPictureView();

            model.Pic_DrawingName = obj.masterData.DiecutPictPath;
            model.Pic_DrawingPath = base64String(hostEnvironment, obj.masterData.DiecutPictPath);

            model.Pic_PrintName = obj.masterData.PrintMasterPath;
            model.Pic_PrintPath = base64String(hostEnvironment, obj.masterData.PrintMasterPath);

            model.Pic_PalletName = obj.masterData.PalletizationPath;
            model.Pic_PalletPath = base64String(hostEnvironment, obj.masterData.PalletizationPath);

            model.Pic_FGName = obj.masterData.FgpicPath;
            model.Pic_FGPath = base64String(hostEnvironment, obj.masterData.FgpicPath);

            return model;
        }

        public TransactionDetail BindDataTransactionDetail(TransactionDataModel model)
        {
            TransactionDetail Detail = new TransactionDetail();
            if (model == null)
            {
                return null;
            }
            Detail.ProductTypDetail = model.modelCategories.ProductTypeName;
            Detail.HierarchyLV2Detail = model.modelCategories.HierarchyLV2;
            Detail.CustNameDetail = model.modelProductCustomer.CustName;
            Detail.MaterialDescriptionDetail = model.modelProductInfo.Description;
            Detail.PCDetail = model.modelProductInfo.PC;
            Detail.BoardDetail = model.modelProductSpec.Board;
            Detail.CostDetail = Convert.ToString(model.modelProductSpec.CostPerTon);
            Detail.RoutingDetail = new List<RoutingDataModel>();
            Detail.RoutingDetail = model.modelRouting.RoutingDataList;
            //RoutingDataList
            return Detail;
        }
        #endregion

        #region Services

        public void SetTransactionStatus(TransactionDataModel model, string transactionName)
        {
            model.TransactionStatus = new TransactionStatusStyle();

            if (transactionName == "Categories")
            {
                model.TransactionStatus.Categories = "active";
                model.TransactionStatus.Customer = "";
                model.TransactionStatus.ProductInformation = "";
                model.TransactionStatus.ProductSpec = "";
                model.TransactionStatus.ProductProperties = "";
                model.TransactionStatus.ProductRouting = "";
                model.TransactionStatus.ProductERPInterface = "";
                model.TransactionStatus.ProductPicture = "";
            }
            else if (transactionName == "Customer")
            {
                model.TransactionStatus.Categories = "done";
                model.TransactionStatus.Customer = "active";
                model.TransactionStatus.ProductInformation = "";
                model.TransactionStatus.ProductSpec = "";
                model.TransactionStatus.ProductProperties = "";
                model.TransactionStatus.ProductRouting = "";
                model.TransactionStatus.ProductERPInterface = "";
                model.TransactionStatus.ProductPicture = "";
            }
            else if (transactionName == "ProductInformation")
            {
                model.TransactionStatus.Categories = "done";
                model.TransactionStatus.Customer = "done";
                model.TransactionStatus.ProductInformation = "active";
                model.TransactionStatus.ProductSpec = "";
                model.TransactionStatus.ProductProperties = "";
                model.TransactionStatus.ProductRouting = "";
                model.TransactionStatus.ProductERPInterface = "";
                model.TransactionStatus.ProductPicture = "";
            }
            else if (transactionName == "ProductSpec")
            {
                model.TransactionStatus.Categories = "done";
                model.TransactionStatus.Customer = "done";
                model.TransactionStatus.ProductInformation = "done";
                model.TransactionStatus.ProductSpec = "active";
                model.TransactionStatus.ProductProperties = "";
                model.TransactionStatus.ProductRouting = "";
                model.TransactionStatus.ProductERPInterface = "";
                model.TransactionStatus.ProductPicture = "";
            }
            else if (transactionName == "ProductProperties")
            {
                model.TransactionStatus.Categories = "done";
                model.TransactionStatus.Customer = "done";
                model.TransactionStatus.ProductInformation = "done";
                model.TransactionStatus.ProductSpec = "done";
                model.TransactionStatus.ProductProperties = "active";
                model.TransactionStatus.ProductRouting = "";
                model.TransactionStatus.ProductERPInterface = "";
                model.TransactionStatus.ProductPicture = "";
            }
            else if (transactionName == "ProductRouting")
            {
                model.TransactionStatus.Categories = "done";
                model.TransactionStatus.Customer = "done";
                model.TransactionStatus.ProductInformation = "done";
                model.TransactionStatus.ProductSpec = "done";
                model.TransactionStatus.ProductProperties = "done";
                model.TransactionStatus.ProductRouting = "active";
                model.TransactionStatus.ProductERPInterface = "";
                model.TransactionStatus.ProductPicture = "";
            }
            else if (transactionName == "ERPInterface")
            {
                model.TransactionStatus.Categories = "done";
                model.TransactionStatus.Customer = "done";
                model.TransactionStatus.ProductInformation = "done";
                model.TransactionStatus.ProductSpec = "done";
                model.TransactionStatus.ProductProperties = "done";
                model.TransactionStatus.ProductRouting = "done";
                model.TransactionStatus.ProductERPInterface = "active";
                model.TransactionStatus.ProductPicture = "";
            }
            else if (transactionName == "Picture")
            {
                model.TransactionStatus.Categories = "done";
                model.TransactionStatus.Customer = "done";
                model.TransactionStatus.ProductInformation = "done";
                model.TransactionStatus.ProductSpec = "done";
                model.TransactionStatus.ProductProperties = "done";
                model.TransactionStatus.ProductRouting = "done";
                model.TransactionStatus.ProductERPInterface = "done";
                model.TransactionStatus.ProductPicture = "active";
            }

        }

        // return UniqueFileName > [0] and base64String > [1]
        public string[] UploadPicture(IFormFile Picture, IHostingEnvironment environment, HttpContext sessionContext)
        {
            var path = Path.Combine(environment.WebRootPath, "Picture");
            string[] result = new string[3];
            string fileName = null;
            string newFileName = null;
            string base64String = null;
            try
            {

                if (Picture == null)
                {
                    result[0] = newFileName;
                    result[1] = base64String;
                    return result;
                }
                //Create Folder 
                if (!(Directory.Exists(path)))
                {
                    Directory.CreateDirectory(path);
                }

                if (Picture != null)
                {
                    //Getting FileName
                    fileName = ContentDispositionHeaderValue.Parse(Picture.ContentDisposition).FileName.Trim('"');

                    //Assigning Unique Filename (Guid)
                    var myUniqueFileName = Convert.ToString(Guid.NewGuid());

                    //Getting file Extension
                    var FileExtension = Path.GetExtension(fileName);

                    // concating  FileName + FileExtension
                    newFileName = myUniqueFileName + FileExtension;



                    // Combines two strings into a path.
                    fileName = path + $@"\{newFileName}";

                    // if you want to store path of folder in database

                    using (FileStream fs = new FileStream(fileName, FileMode.Create))
                    {
                        //Picture.CopyToAsync(fs);
                        Picture.CopyTo(fs);

                        //   fs.Flush();


                    }

                    Byte[] bytes = File.ReadAllBytes(fileName);
                    string src = "data:" + Picture.ContentType + ";base64,";
                    base64String = src + Convert.ToBase64String(bytes);

                }


                result[0] = newFileName;
                result[1] = base64String;
                return result;
            }
            catch (Exception ex)
            {
                return result = null;
            }

        }

        public string base64String(IHostingEnvironment environmentstring, string fileName)
        {
            string base64String;

            try
            {
                var path = Path.Combine(environmentstring.WebRootPath, "Picture");
                string FullfileName, type;
                Byte[] bytes;
                string src;
                int len;
                FullfileName = path + $@"\{fileName}";
                type = Path.GetExtension(fileName);
                len = type.Length;
                src = "data:image/" + type.Substring(1, len - 1) + ";base64,";
                bytes = File.ReadAllBytes(FullfileName);
                base64String = src + Convert.ToBase64String(bytes);

            }
            catch (Exception ex)
            {
                base64String = null;
            }
            return base64String;

        }

        public string ConvertImageToBase64(IFormFile image)
        {
            // Convert to Bytes
            byte[] byteImage = null;
            BinaryReader reader = new BinaryReader(image.OpenReadStream());
            byteImage = reader.ReadBytes((int)image.Length);

            // Convert to Base64String
            string base64StringImage = "data:" + image.ContentType + ";base64," + Convert.ToBase64String(byteImage);
            return base64StringImage;
        }

        public void DeleteFile(string Path)
        {
            System.IO.FileInfo fi = new System.IO.FileInfo(Path);
            try
            {
                fi.Delete();
            }
            catch (System.IO.IOException e)
            {
                Console.WriteLine(e.Message);
            }

        }

        #endregion
    }
}
