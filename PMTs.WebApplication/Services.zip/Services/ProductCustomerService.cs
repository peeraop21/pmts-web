﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PMTs.DataAccess;
using PMTs.DataAccess.Models;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.NewProduct;
using PMTs.DataAccess.Repository;
using PMTs.DataAccess.Repository.Interfaces;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PMTs.WebApplication.Services
{
    public class ProductCustomerService : IProductCustomerService
    {

        IHttpContextAccessor _httpContextAccessor;

        private readonly ICustomerAPIRepository _customerAPIRepository;
        private readonly ICustShipToAPIRepository _custShipToAPIRepository;

        private readonly string _username;
        private readonly string _saleOrg;
        private readonly string _plantCode;

        public ProductCustomerService(IHttpContextAccessor httpContextAccessor, ICustomerAPIRepository customerAPIRepository, ICustShipToAPIRepository custShipToAPIRepository)
        {
            // Initialize HttpContext
            _httpContextAccessor = httpContextAccessor;

            // Initialize Repository
            _customerAPIRepository = customerAPIRepository;
            _custShipToAPIRepository = custShipToAPIRepository;

            // Initialize SaleOrg and PlantCode from Session
            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
            _username = userSessionModel.UserName;
            _saleOrg = userSessionModel.SaleOrg;
            _plantCode = userSessionModel.PlantCode;
        }

        public void GetCustomer(TransactionDataModel transactionDataModel)
        {
            try
            {
                transactionDataModel.modelProductCustomer.CustomerList = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.Customer>>(Convert.ToString(_customerAPIRepository.GetCustomerList(_saleOrg, _plantCode)));
                transactionDataModel.modelProductCustomer.CustShipToList = JsonConvert.DeserializeObject<List<DataAccess.ModelsNew.CustShipTo>>(Convert.ToString(_custShipToAPIRepository.GetCustShipToList(_saleOrg, _plantCode)));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public TransactionDataModel CustomerData(PMTsDbContext context, HttpContext sessionContext, TransactionDataModel transactionDataModel)
        {
            TransactionDataModel model = new TransactionDataModel();

            try
            {
                model = SessionExtentions.GetSession<TransactionDataModel>(_httpContextAccessor.HttpContext.Session, "TransactionDataModel");
                model.modelProductCustomer = new ProductCustomer();
                model.modelProductCustomer = transactionDataModel.modelProductCustomer;
            }
            catch (Exception ex)
            {
                model.modelProductCustomer = new ProductCustomer();
            }

            return model;

        }

        //public List<v_CustomerShipTo> Search(PMTsDbContext context, HttpContext sessionContext, string Prefix)
        //{
        //    SessionsModel sessions = new SessionsModel
        //    {
        //        UserName = sessionContext.Session.GetString("username"),
        //        SaleOrg = sessionContext.Session.GetString("SALE_ORG"),
        //        PlantCode = sessionContext.Session.GetString("PLANT_CODE"),
        //    };

        //    var customer = CustomerRepository.GetCustomeSearch(context, Prefix, sessions);

        //    return customer;
        //}
    }
}
