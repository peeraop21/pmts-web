﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using PMTs.DataAccess.ModelsNew;
using PMTs.DataAccess.ModelView;
using PMTs.DataAccess.ModelView.Login;
using PMTs.DataAccess.ModelView.MaintenanceCustomer;
using PMTs.DataAccess.Repository;
using PMTs.DataAccess.Repository.Interfaces;
using PMTs.DataAccess.Shared;
using PMTs.WebApplication.Extentions;
using PMTs.WebApplication.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PMTs.WebApplication.Services
{
    public class MaintenanceCustomerService : IMaintenanceCustomerService
    {

        IHttpContextAccessor _httpContextAccessor;

        private readonly ICustomerAPIRepository _customerAPIRepository;
        private readonly ICustShipToAPIRepository _custShipToAPIRepository;

        private readonly string _username;
        private readonly string _saleOrg;
        private readonly string _plantCode;

        public MaintenanceCustomerService(IHttpContextAccessor httpContextAccessor, ICustomerAPIRepository customerAPIRepository, ICustShipToAPIRepository custShipToAPIRepository)
        {
            // Initialize HttpContext
            _httpContextAccessor = httpContextAccessor;

            // Initialize Repository
            _customerAPIRepository = customerAPIRepository;
            _custShipToAPIRepository = custShipToAPIRepository;

            // Initialize SaleOrg and PlantCode from Session
            var userSessionModel = SessionExtentions.GetSession<UserSessionModel>(_httpContextAccessor.HttpContext.Session, "UserSessionModel");
            _username = userSessionModel.UserName;
            _saleOrg = userSessionModel.SaleOrg;
            _plantCode = userSessionModel.PlantCode;
        }

        public void GetCustomer(MaintenanceCustomerViewModel maintenanceCustomerViewModel)
        {
            // Convert Json String to List Object
            var customerList = JsonConvert.DeserializeObject<List<Customer>>(_customerAPIRepository.GetCustomerList(_saleOrg, _plantCode));

            // Convert List Object to List Object View Model
            var customerModelViewList = Mapper.Map<List<Customer>, List<CustomerViewModel>>(customerList);

            maintenanceCustomerViewModel.CustomerViewModelList = customerModelViewList;

            ////////////////////////////////////////////////////////////////////////////////////////////////////

            // Convert Json String to List Object
            var custShipToList = JsonConvert.DeserializeObject<List<CustShipTo>>(_custShipToAPIRepository.GetCustShipToList(_saleOrg, _plantCode));

            maintenanceCustomerViewModel.CustShipToList = custShipToList;
        }

        public void SaveCustomer(MaintenanceCustomerViewModel model)
        {
            List<string> custShipToArrayList = model.CustShipToArrayList.Split(',').ToList<string>();
            List<CustShipTo> custShipToList = new List<CustShipTo>();

            custShipToArrayList.ForEach(i =>
            {
                custShipToList.Add(new CustShipTo
                {
                    ShipTo = i,
                    CustCode = model.CustomerViewModel.CustCode,
                });
            });

            model.CustomerViewModel.CustStatus = true;

            ParentModel customerModel = new ParentModel();
            customerModel.AppName = Globals.AppNameEncrypt;
            customerModel.SaleOrg = _saleOrg;
            customerModel.PlantCode = _plantCode;

            ParentModel custShipToModel = new ParentModel();
            custShipToModel.AppName = Globals.AppNameEncrypt;
            custShipToModel.SaleOrg = _saleOrg;
            custShipToModel.PlantCode = _plantCode;

            model.CustomerViewModel.SaleOrg = _saleOrg;
            model.CustomerViewModel.PlantCode = _plantCode;

            customerModel.Customer = Mapper.Map<CustomerViewModel, Customer>(model.CustomerViewModel);

            custShipToModel.CustShipToList = custShipToList;

            string customerListJsonString = JsonConvert.SerializeObject(customerModel);
            string custShipToListJsonString = JsonConvert.SerializeObject(custShipToModel);

            _customerAPIRepository.SaveCustomer(customerListJsonString);
            _custShipToAPIRepository.SaveCustShipToList(custShipToListJsonString);
        }

        public void UpdateCustomer(CustomerViewModel customerViewModel)
        {
            customerViewModel.CustStatus = true;

            ParentModel customerModel = new ParentModel();
            customerModel.AppName = Globals.AppNameEncrypt;
            customerModel.SaleOrg = _saleOrg;
            customerModel.PlantCode = _plantCode;
            customerModel.Customer = Mapper.Map<CustomerViewModel, Customer>(customerViewModel);

            string jsonString = JsonConvert.SerializeObject(customerModel);

            _customerAPIRepository.UpdateCustomer(jsonString);
        }

        public void SetCustomerStatus(CustomerViewModel customerViewModel)
        {
            customerViewModel.CustStatus = false;

            string jsonString = JsonConvert.SerializeObject(customerViewModel);

            _customerAPIRepository.UpdateCustomer(jsonString);
        }
    }
}
